-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 12, 2019 at 05:25 AM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 7.3.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `authentication`
--
CREATE DATABASE IF NOT EXISTS `authentication` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `authentication`;

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `job_title` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `name`, `email`, `job_title`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(3, 'Binam', 'Binam_425@gmail.com', 'Manager', '$2y$10$RFXNWjJ7yJL2f/7ZbF8eneZD/hHT1fMNPNrT4hwGcayLmg57Uwfwu', 'lOY41CXYw0ToYmwiFSWeqNSgrb8F5pliVh25xolx0BOOOwBjHFdFnuoexohI', '2019-09-27 09:08:28', '2019-09-27 09:08:28');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_09_27_081040_create_admins_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `password_resets`
--

INSERT INTO `password_resets` (`email`, `token`, `created_at`) VALUES
('Binam_425@gmail.com', '$2y$10$8ZeGMfdlsE6m1I.3Hh7kOO4SsfCI9TatD1QZRvJLE2EBsWlG5uCSa', '2019-09-29 03:44:20');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Jenish', 'Jenish@gmail.com', '$2y$10$BY1tWVeSOW/9hTbzHAwhruW1qVq3wFkwzSzgyA9S5/QEAxb7eq/y.', 'xJF7vnhDzXtIVOgbjBCQgrVyWIuzN2uExUkecAzccm03M84vCJsCzVLDXA6U', '2019-09-27 02:57:49', '2019-09-27 02:57:49');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `admins_email_unique` (`email`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;--
-- Database: `blogsimple`
--
CREATE DATABASE IF NOT EXISTS `blogsimple` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `blogsimple`;

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `name`, `email`, `password`, `created_at`, `updated_at`) VALUES
(1, 'Admin', 'admin@gmail.com', '$2y$10$GF3URv03qvSMWBHwmEsRLeCoiAdrxWz/B5d5cWA1NBDcppKCmLI3K', '2019-10-30 10:11:05', '2019-10-30 10:11:13');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(4, '2014_10_12_000000_create_users_table', 1),
(5, '2014_10_12_100000_create_password_resets_table', 1),
(6, '2019_08_19_000000_create_failed_jobs_table', 1),
(7, '2019_10_30_153155_create_admins_table', 2),
(8, '2019_11_01_072349_create_tags_table', 3),
(9, '2019_11_01_081623_create_posts_table', 4);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` varchar(141) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tag_id` varchar(141) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `post_name` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_desc` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `user_id`, `tag_id`, `post_name`, `post_desc`, `created_at`, `updated_at`) VALUES
(2, '1', '5', 'My lonely friend Callum Scott', 'Callum talks to ghost and can see every dead spirits', '2019-11-02 10:33:14', '2019-11-04 01:18:46'),
(3, '2', '5', 'Help old age', 'In November 5th we the member of group old age sewa.', '2019-11-03 06:56:22', '2019-11-03 06:56:22'),
(4, '1', '5', 'Travel guide to Ghandruk', 'Enjoy my blog on trek to ghandruk via youtube bhavesh', '2019-11-03 07:35:02', '2019-11-04 01:18:33'),
(5, '3', '5', 'Indra Jatra', 'Visit Bhaktapur during Indra Jatra to experience the rich newari culture', '2019-11-04 02:18:58', '2019-11-04 02:18:58'),
(6, '2', '7', 'Bully', 'I have dog named bully who is a bull dog by breed', '2019-11-05 02:03:56', '2019-11-05 02:03:56'),
(7, '2', '8', 'Thomas', 'Thomas is a friendly ghost by nature', '2019-11-05 02:04:32', '2019-11-05 02:04:32'),
(8, '4', '5', 'Reunion at Calm', 'We four friends had met at Calm, TangalWoods', '2019-11-05 06:52:41', '2019-11-05 06:52:41');

-- --------------------------------------------------------

--
-- Table structure for table `tags`
--

CREATE TABLE `tags` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tag_name` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tag_descripiton` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tags`
--

INSERT INTO `tags` (`id`, `tag_name`, `tag_descripiton`, `created_at`, `updated_at`) VALUES
(5, 'Social Media', 'Social media related fields included', '2019-11-01 02:10:17', '2019-11-01 02:24:32'),
(7, 'Pets and animals', 'Pets and animal related posts', '2019-11-01 02:11:36', '2019-11-01 02:11:36'),
(8, 'Fictional', 'Fictional posts', '2019-11-01 02:11:46', '2019-11-01 02:11:46');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(141) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobileno` varchar(141) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `profile_image` varchar(141) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `address`, `mobileno`, `profile_image`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Suraj', 'Suraj@gmail.com', NULL, '$2y$10$Fl7FMWd7BoWxlPE/lFgJ.uE/AFA8IxZ..5.ypEsyWaXgKeEoh/sfG', 'Ranipauwa', '9810287890', '1ca28875eb35409e5277f989f9af75fcb9a10216.jpg', NULL, '2019-11-01 02:44:03', '2019-11-04 02:00:29'),
(2, 'Jenish', 'Jenish@yopmail.com', NULL, '$2y$10$Dnkqq53v8cr3QlDCC5Sa/ev1VuI.clsxH5qfIDdvJH85aaxUaOL6a', 'Baniyatar', '9810287891', 'dfc1e225af14824690cce234acb9a19c455028d9.jpg', NULL, '2019-11-03 04:32:11', '2019-11-04 02:01:41'),
(3, 'Kabita Manadhar', 'Kabita@yopmail.com', NULL, '$2y$10$XDzCFE8xeZXrwnpfRTaYw./YBY5LomBoSRKr1c.LR3r4J/0Lp6OoW', 'Baniyatar', '9810175748', '82fd834b00d6d5c8e5a196b334bab1821a28fdbd.jpg', NULL, '2019-11-04 02:16:07', '2019-11-04 02:18:09'),
(4, 'Saramsa Sherchan', 'sherchan_hari@live.com', NULL, '$2y$10$gvTXxKonfuMCg/3uMiyr4uT7HmKGhDoo.AtRbxiBZlNpUbH/upNUq', 'Basundhara', '9810287891', 'b1bd3c07cdb504ab6d3471a6f073fc3201a397d9.jpg', NULL, '2019-11-05 06:35:46', '2019-11-05 06:52:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `admins_email_unique` (`email`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tags`
--
ALTER TABLE `tags`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `tags`
--
ALTER TABLE `tags`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;--
-- Database: `ecom`
--
CREATE DATABASE IF NOT EXISTS `ecom` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `ecom`;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2019_03_18_150538_create_products_table', 1),
(3, '2019_03_19_034626_create_users_table', 2);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `imagePath` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `created_at`, `updated_at`, `imagePath`, `title`, `description`, `price`) VALUES
(11, '2019-03-18 21:58:59', '2019-03-18 21:58:59', 'images/1.jpg', 'Chicken Momo', 'Very Tasty and juciy momo!', 200),
(12, '2019-03-18 21:58:59', '2019-03-18 21:58:59', 'images/dish1.jpg', 'Chicken Chilly', 'Very Tasty and juciy chicken!', 250),
(13, '2019-03-18 21:58:59', '2019-03-18 21:58:59', 'images/dish4.jpg', 'Peanut Sadheko', 'Very Tasty', 150),
(14, '2019-03-18 21:58:59', '2019-03-18 21:58:59', 'images/dish5.jpg', 'Peanut Sadheko', 'Very Tasty', 150),
(15, '2019-03-18 21:58:59', '2019-03-18 21:58:59', 'images/dish7.jpg', 'Peanut Sadheko', 'Very Tasty', 150);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `email` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `created_at`, `updated_at`, `email`, `password`, `remember_token`) VALUES
(1, '2019-03-20 05:31:38', '2019-03-20 05:31:38', 'admin@gmail.com', '$2y$10$oPbvcgA46t/8tVdUNZ2toeKs84blXTaBaHz187T/MjE9C0.FaudOi', 'lKGXVFS8j7LHTepEbcve4vfQmp7DDRYAVtO2mBiDfhaESLMAbki5Hma3o5RT'),
(2, '2019-03-20 05:39:13', '2019-03-20 05:39:13', 'john@gmail.com', '$2y$10$egLr0mxW2ZeM8gVlWwddn.ORofRJouDGULb1mObIfUyRledFkB.Dm', 'UJKny4A33uBAdDlnafVPMsFpLIL6sy18TDRGNR0I5VpgsJmQtcQ0MfUeUhuj'),
(3, '2019-03-20 05:56:25', '2019-03-20 05:56:25', 'sherchan_hari@live.com', '$2y$10$mya6nnVdDfuI6SQ5MaGMt.v4oQYc02GnfFNmgQFAJLUixDgb6UpKG', 'kvzksqJl1dwkjPN8ZF4bBncRkfQGw4K06Hfviftzy4imUojT7wUejW07Vnlo'),
(4, '2019-03-24 00:25:36', '2019-03-24 00:25:36', 'dhewaju@gmail.com', '$2y$10$yAghul.Tr2BSASW1ysKaDOEppIFCGeen.r7ee9qSCnYw9qAqwb8bi', 'wCCYHABAKyKk2NqYE9hVLSDhAbG1e0e6ApqoitlmVDNeZPlP2oIktobp7DZ4'),
(5, '2019-03-24 02:55:35', '2019-03-24 02:55:35', 'admn@gmail.com', '$2y$10$4s4wInYye1Guf0ad9h3DLOHQW..feDfDYGGMTHByJjsp4k2ano8tq', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;--
-- Database: `electronics`
--
CREATE DATABASE IF NOT EXISTS `electronics` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `electronics`;

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(10) UNSIGNED NOT NULL,
  `username` varchar(144) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(144) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(144) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `username`, `email`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Admin', 'Admin@gmail.com', '$2y$10$KVUUTnbmoW5sNUUBt01Lf.8j599RoaHCQNyE2wciWb5sk72MQBAn.', 'VSPi5g3VUdrWhQVvPd7qL4Bo0bAPsrGItufPsYJ7nUuGRGH1j9bFt1vnm8JD', '2019-10-06 06:41:24', '2019-10-06 06:41:33');

-- --------------------------------------------------------

--
-- Table structure for table `carts`
--

CREATE TABLE `carts` (
  `id` int(10) UNSIGNED NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_name` varchar(144) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` double(8,2) NOT NULL,
  `quantity` int(11) NOT NULL,
  `user_email` varchar(144) COLLATE utf8mb4_unicode_ci NOT NULL,
  `session_id` varchar(144) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `parent_id` int(11) NOT NULL,
  `name` varchar(144) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `parent_id`, `name`, `description`, `created_at`, `updated_at`) VALUES
(1, 0, 'Tvs', 'Includes wide range of Tvs such as LED,LCDS,OLED etc.', '2019-10-06 06:42:40', '2019-10-06 06:42:40'),
(2, 0, 'Mobile Phones', 'Includes mobile phones from wide range of comapnies including samsung,Apple,MI,etc.', '2019-10-06 06:43:16', '2019-10-06 06:43:16'),
(3, 0, 'Headphones', 'Includes wide range of headphones such as Sony,Beats etc.', '2019-10-06 06:43:44', '2019-10-06 06:43:44');

-- --------------------------------------------------------

--
-- Table structure for table `delievery_addresses`
--

CREATE TABLE `delievery_addresses` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `name` varchar(144) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_email` varchar(144) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(144) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(144) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobileno` varchar(144) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `delievery_addresses`
--

INSERT INTO `delievery_addresses` (`id`, `user_id`, `name`, `user_email`, `address`, `city`, `mobileno`, `created_at`, `updated_at`) VALUES
(1, 1, 'Binam', 'Binam_425@gmail.com', 'Baneshwor', 'Kathmandu', '9810175677', '2019-10-08 21:46:04', '2019-10-10 05:16:24'),
(2, 2, 'Saramsa Sherchan', 'ssaramsa@gmail.com', 'Basundhara', 'Kathmandu', '9810173766', '2019-10-10 05:26:08', '2019-10-10 05:26:08');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(144) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_10_01_115000_create_admins_table', 1),
(4, '2019_10_01_131405_create_categories_table', 1),
(5, '2019_10_02_041745_create_products_table', 1),
(6, '2019_10_03_165424_create_carts_table', 1),
(7, '2019_10_06_103348_create_delievery_addresses_table', 1),
(8, '2019_10_10_033849_create_orders_table', 2),
(9, '2019_10_10_040712_create_orderproducts_table', 3);

-- --------------------------------------------------------

--
-- Table structure for table `orderproducts`
--

CREATE TABLE `orderproducts` (
  `id` int(10) UNSIGNED NOT NULL,
  `order_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_name` varchar(144) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `orderproducts`
--

INSERT INTO `orderproducts` (`id`, `order_id`, `user_id`, `product_id`, `product_name`, `price`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 10, 'Huawei P20 Pro', 60000, '2019-10-10 03:15:33', '2019-10-10 03:15:33'),
(2, 1, 1, 7, 'Samsung Note 10 (8GB+ 256 GB)', 120000, '2019-10-10 03:15:33', '2019-10-10 03:15:33'),
(3, 2, 1, 4, 'Beats Solo 3', 40000, '2019-10-10 05:16:40', '2019-10-10 05:16:40'),
(4, 3, 2, 9, 'OnePlus 6T', 90000, '2019-10-10 05:27:28', '2019-10-10 05:27:28'),
(5, 3, 2, 5, 'Beats Studio 3', 20000, '2019-10-10 05:27:28', '2019-10-10 05:27:28');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_email` varchar(144) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(144) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(144) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(144) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobileno` varchar(144) COLLATE utf8mb4_unicode_ci NOT NULL,
  `discount_amount` double(8,2) NOT NULL,
  `grand_total` double(8,2) NOT NULL,
  `order_status` varchar(144) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_method` varchar(144) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `user_email`, `name`, `address`, `city`, `mobileno`, `discount_amount`, `grand_total`, `order_status`, `payment_method`, `created_at`, `updated_at`) VALUES
(1, 1, 'Suraj@gmail.com', 'Binam', 'Baneshwor', 'Kathmandu', '9810175677', 18000.00, 162000.00, 'Pending', 'Khalti', '2019-10-10 03:15:33', '2019-10-10 07:22:58'),
(2, 1, 'Suraj@gmail.com', 'Binam', 'Baneshwor', 'Kathmandu', '9810175677', 4000.00, 40000.00, 'New', 'Khalti', '2019-10-10 05:16:39', '2019-10-10 05:16:39'),
(3, 2, 'sankalapa_sherchan@gmail.com', 'Saramsa Sherchan', 'Basundhara', 'Kathmandu', '9810173766', 11000.00, 99000.00, 'New', 'Khalti', '2019-10-10 05:27:28', '2019-10-10 05:27:28');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(144) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(144) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(10) UNSIGNED NOT NULL,
  `category_id` int(11) NOT NULL,
  `product_name` varchar(144) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` double(8,2) NOT NULL,
  `image` varchar(144) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `category_id`, `product_name`, `product_description`, `price`, `image`, `created_at`, `updated_at`) VALUES
(1, 1, 'Sony Bravia 40W652D', 'Since the evolution of the TV, man has been fascinated by the device. After CRT TV’s Thin tubes are ruling the market today. This Sony BRAVIA KLV-40W652D 40 inch LED Full HD TV features a 40 Inch, LED, Full HD, 1920x1080 display for your viewing pleasure. The Aspect Ratio of this screen is 16 : 9 to meet the latest standards and consumes 59.4 W as power (when running). Other features of this TV include Bravia Sync, Display Mirroring, MHL, SmartShare, SmartView, WiFi Direct, Future Ready.', 150000.00, '999b00f9ed89b416a86e1777152251a1b153681d.png', '2019-10-06 06:45:52', '2019-10-06 06:45:52'),
(2, 1, 'LG 32 inch Smart HD TV 32LK610B', 'See high definition in a way not previously possible. High dynamic range is now available on high-definition televisions with LG’s advanced tone mapping technology that provides scene-by-scene optimization for a more striking HD image. (HDR10 and HLG formats supported.)', 140000.00, '2f9c372a999a18ba44b875c8b79a265107a7fcac.png', '2019-10-06 06:50:17', '2019-10-06 06:50:17'),
(3, 1, 'Samsung 55\" Class The Frame QLED Smart 4K UHD TV (2019)', 'When you\'re done watching shows in QLED 4K UHD, The Frame transforms into a beautiful work of art. Just activate Art Mode and discover many options that compliment your room. Find artwork you love, with choices based on color or preferences like noteworthy masterpieces, the Samsung Art Store makes it fun and easy to discover a wide variety of art for all occasions.', 100000.00, 'e85ce7ed62b8eb188bdbf765b9dded3742e448c1.png', '2019-10-06 06:51:11', '2019-10-06 06:51:11'),
(4, 3, 'Beats Solo 3', 'These Beats headphones were the first fruits of Apple\'s deal to buy the Beats brand – in terms of actual products at least – and the review below represents our initial thoughts when the headphones first appeared in 2016.\r\n\r\nWhen Apple bought the Beats brand, it was only a matter of time before that Cupertino mobile know-how would be baked into Dr Dre\'s personal audio line. The Solo 3 wireless are the first obvious fruits of that partnership in terms of products, taking an existing Beat Audio line and giving them a sprinkle of Apple\'s magic dust.', 40000.00, 'a3aa7940ade6ea082303faa3bf8557cde9b1c8f3.png', '2019-10-06 06:53:17', '2019-10-06 06:53:17'),
(5, 3, 'Beats Studio 3', 'The Studio 3\'s or the Sony 1000\'s. The Studio\'s stood out in ear cup comfort, Bluetooth range and style, but the audiophiles seemed to agree that the 1000\'s were superior. Although I don\'t own a set of Sony\'s, I had a chance to borrow a pair and do some side-by-side testing with my own ears. What I found is that as many have said, the Beats sweet spot is bass performance in terms of audio quality and overall, I\'d have to give it to the Sony\'s. However, read on for the reason for my 5 stars.', 20000.00, '8faff610f8f45b987c8aecf54cf7a9b936b29ddc.png', '2019-10-06 06:55:48', '2019-10-06 06:55:48'),
(6, 3, 'Sony Mdr V6', 'Circum-Aural design reduces noise from the outside world.\r\n\r\nOval ear-pads for extra isolation.\r\n\r\n40 MM diameter drivers to provide wide surface area for superb dynamics and deep bass down to 5 Hz.\r\n\r\nOxygen-free copper litz cord for maximum conductivity and minimum noise.', 30000.00, '529dad68591e345d51ee0798659c2453b210e4f3.jpg', '2019-10-06 06:56:38', '2019-10-06 06:56:38'),
(7, 2, 'Samsung Note 10 (8GB+ 256 GB)', 'Circum-Aural design reduces noise from the outside world.\r\n\r\nOval ear-pads for extra isolation.\r\n\r\n40 MM diameter drivers to provide wide surface area for superb dynamics and deep bass down to 5 Hz.\r\n\r\nOxygen-free copper litz cord for maximum conductivity and minimum noise.', 120000.00, 'b9211769dd2f5cc3fd510e309f955cf705829863.png', '2019-10-06 06:58:08', '2019-10-06 06:58:08'),
(8, 2, 'Samsung A-50', 'The Samsung Galaxy A50 is a well-equipped mid-range smartphone with interesting features. It comes with an excellent FHD+ display compared to the budget. The processor is well enough for the operation task. In terms of storage, the phone has great storage capacity. The fingerprint sensor is provided on the board. The cameras are capable enough to capture a detailed picture. Overall, it is a favorable option in this price segment.', 30000.00, '6cea114062a5f74617f38fd251e215854396a294.png', '2019-10-06 06:59:55', '2019-10-06 06:59:55'),
(9, 2, 'OnePlus 6T', 'The capacitive touchscreen is protected against minor breaks and tears through a corning gorilla glass v6. It functions on Android v9.0 (Pie) operating system and driven by Octa-core (2.8 GHz, Quad core, Kryo 385 + 1.8 GHz, Quad core, Kryo 385) processor paired with 6 GB of RAM.', 90000.00, '0ab043c4c564a6060dbcaabbb16858ee9e6af7ac.png', '2019-10-06 07:00:30', '2019-10-06 07:00:30'),
(10, 2, 'Huawei P20 Pro', 'Huawei P20 Pro Price in Nepal. The Huawei P20 Pro is available in 6 GB RAM and 128 GB ROM variant, and Huawei has priced the device at Rs. 99,900 in Nepal. With the price tag, the smartphone goes directly up against the Samsung Galaxy S9 Plus which also sells for Rs. 99,900', 60000.00, '838ed4a7de09f7b68c141fbed830208c9ff78437.png', '2019-10-06 07:01:09', '2019-10-06 07:01:09');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(144) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(144) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobileno` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(144) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `mobileno`, `address`, `city`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Suraj', 'Suraj@gmail.com', '9810287891', 'Tukuche', 'Mustang', '$2y$10$GH2FFoS/DtwKxZEenBBNg./cu.MV1NWJRLzTsG2.wTStVk3CgFRl.', 'WnsnvZW6vQrBleh0V4yOz0tNktYUtwqlvICqlwfqYc0x7NcgiZxRtlKQACIn', '2019-10-06 07:23:15', '2019-10-10 05:16:24'),
(2, 'Sankalpa Sherchan', 'sankalapa_sherchan@gmail.com', '9813064603', 'Bhairabtole', 'Pokhara', '$2y$10$2oHjXz217IGQW8TVYdpMleaWTadk9WjG38owBSEZS1ZHn08qLBq2O', 'nXAt0dJNf35yV7kaIUOgPwTAV7FGa7QlwN90fuNqfUbdPdu9mg39YP9nkLEZ', '2019-10-10 05:24:33', '2019-10-10 05:26:08');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `carts`
--
ALTER TABLE `carts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `delievery_addresses`
--
ALTER TABLE `delievery_addresses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orderproducts`
--
ALTER TABLE `orderproducts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `carts`
--
ALTER TABLE `carts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `delievery_addresses`
--
ALTER TABLE `delievery_addresses`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `orderproducts`
--
ALTER TABLE `orderproducts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;--
-- Database: `finalpractice`
--
CREATE DATABASE IF NOT EXISTS `finalpractice` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `finalpractice`;

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `username` varchar(144) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(144) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(144) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `blogs`
--

CREATE TABLE `blogs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_email` varchar(144) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(144) COLLATE utf8mb4_unicode_ci NOT NULL,
  `body` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `blogs`
--

INSERT INTO `blogs` (`id`, `user_email`, `title`, `body`, `created_at`, `updated_at`) VALUES
(1, 'Suraj@yopmail.com', 'Post one', 'This is post one', '2019-10-17 02:49:41', '2019-10-17 02:49:41'),
(2, 'Suraj@yopmail.com', 'Post two', 'Post second is by Suraj Don', '2019-10-17 04:42:03', '2019-10-17 04:42:03'),
(3, 'Anish@gmail.com', 'Post three', 'Post three is a new body', '2019-10-17 04:56:25', '2019-10-17 04:56:25'),
(4, 'Jenish@yopmail.com', 'Gloves', 'Saramsa Sherchan has my gloves nigga', '2019-10-18 23:38:33', '2019-10-18 23:38:33');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(144) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_10_15_091807_create_admins_table', 1),
(5, '2019_10_17_081007_create_blogs_table', 2);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(144) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(144) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(144) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(144) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `password` varchar(144) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobileno` varchar(144) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(144) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `profile_image` varchar(144) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `status`, `password`, `mobileno`, `address`, `profile_image`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Suraj', 'Suraj@yopmail.com', NULL, 0, '$2y$10$wzi8lik7/hmpw8hE8M9a4.UjuqRCwyDGs8R8QcvPgdm2f6Aietc7a', '9810287891', 'Ranipauwa', '1262a1e6a0daa9f8d3b938e857e84a7e92932278.png', NULL, '2019-10-17 01:27:32', '2019-10-17 04:41:27'),
(2, 'Anish', 'Anish@gmail.com', NULL, 0, '$2y$10$SVUcmYP6eS9DDz/dIC1bN.ka446nRoslKZoalpKhlws9DV5HyCKfe', '9810287894', 'Chorepatan-4', '10b38f3daa172003fb3cdb6c47a335548fee513d.png', NULL, '2019-10-17 04:53:28', '2019-10-17 04:56:02'),
(3, 'Jenish', 'Jenish@yopmail.com', NULL, 0, '$2y$10$hx8YaCbiw6WLc/wpUcdc4eC9oiK3/YCnkljTuVNspxql0at9u5sVS', NULL, NULL, NULL, NULL, '2019-10-18 23:27:28', '2019-10-18 23:27:28'),
(4, 'sushan Dhewaju', 'sushan@yopmail.com', NULL, 0, '$2y$10$XX6T6dAPe8zgAUc8MWl37u6PI/q8EIaFUiMbCm1zYgaGc3DB0aBcm', NULL, NULL, NULL, NULL, '2019-10-19 22:06:51', '2019-10-19 22:06:51'),
(5, 'Karma', 'Karma@yopmail.com', NULL, 0, '$2y$10$yv7AoGSoA7b.Q6AIdLMG.en.gbYoown1RexKkvDngl5fuq3ITT7re', NULL, NULL, NULL, NULL, '2019-10-19 22:20:19', '2019-10-19 22:20:19'),
(6, 'Suraj', 'Suraj123@gmail.com', NULL, 0, '$2y$10$PC1cPC8l8PiGuoE8WUNxmuzYuoixWPs0dbkYU56GZ9SnV1T0HNnfy', NULL, NULL, NULL, NULL, '2019-10-19 22:31:54', '2019-10-19 22:31:54'),
(7, 'Kentaro', 'Kentaro@yopmail.com', NULL, 1, '$2y$10$QdIZpJB46cMRnA1HwM7V2uy3FxTR8QKY51WFQE5sGwTAg8KNS.rVu', NULL, NULL, NULL, NULL, '2019-10-19 22:33:06', '2019-10-19 22:48:44');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blogs`
--
ALTER TABLE `blogs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `blogs`
--
ALTER TABLE `blogs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;--
-- Database: `imageupload`
--
CREATE DATABASE IF NOT EXISTS `imageupload` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `imageupload`;

-- --------------------------------------------------------

--
-- Table structure for table `profileimage`
--

CREATE TABLE `profileimage` (
  `id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `profileimage`
--

INSERT INTO `profileimage` (`id`, `userid`, `status`) VALUES
(1, 3, 1);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `first` varchar(256) NOT NULL,
  `last` varchar(256) NOT NULL,
  `username` varchar(256) NOT NULL,
  `password` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `first`, `last`, `username`, `password`) VALUES
(2, 'saramsa', 'Sherchan', 'Sar425', '$2y$10$sEki7OdrOOub4LxXwx8rM.0R4wtfaGA.jPwNtgyOdPLUGOTMH0oDS'),
(3, 'Suraj', 'Sherchan', 'suraj44', '$2y$10$JggHL9DQjTk3oid.j6HUmuizejFSPIvMp750BjGRzYS9/wt19J2iO'),
(4, 'Suraj', 'Sherchan', 'suraj44', '$2y$10$3xMNgcCw8fsgpAfxFKJSAeiNWWt7zplrrmgHjyApVibcHKFYlkIcm'),
(5, 'Suraj', 'Sherchan', 'suraj44', '$2y$10$tDpnirugUlKQvzCprR5pSuog69p.1KyTAMUCr1facKFv35TnzKlia'),
(6, 'Suraj', 'Sherchan', 'suraj44', '$2y$10$ly7i/UBGSn5lOUmnOZqlau8J.vVkbKTdIJ6zh.u5.4AEZwOXjEZUG');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `profileimage`
--
ALTER TABLE `profileimage`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `profileimage`
--
ALTER TABLE `profileimage`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;--
-- Database: `internpractice`
--
CREATE DATABASE IF NOT EXISTS `internpractice` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `internpractice`;

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(10) UNSIGNED NOT NULL,
  `body` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `commentable_id` int(11) NOT NULL,
  `commentable_type` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `body`, `commentable_id`, `commentable_type`, `created_at`, `updated_at`) VALUES
(1, 'This comment is from post', 2, 'posts', '2019-09-08 01:55:32', '2019-09-08 01:55:32'),
(2, 'This comment is from videos', 2, 'videos', '2019-09-08 01:55:47', '2019-09-08 01:55:47');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(7, '2014_10_12_000000_create_users_table', 1),
(8, '2014_10_12_100000_create_password_resets_table', 1),
(9, '2019_09_02_070627_create_products_table', 1),
(10, '2019_09_07_042548_create_songs_table', 1),
(11, '2019_09_07_150117_create_passports_table', 1),
(12, '2019_09_07_160410_create_mobiles_table', 1),
(13, '2019_09_08_033257_create_roles_table', 2),
(14, '2019_09_08_033351_create_role_user_table', 2),
(15, '2019_09_08_072440_create_posts_table', 3),
(16, '2019_09_08_072540_create_videos_table', 3),
(17, '2019_09_08_072603_create_comments_table', 3),
(18, '2019_09_08_090756_create_lists_table', 4),
(19, '2019_09_08_092255_create_works_table', 5),
(21, '2019_09_10_152419_add_user_id_products_table', 6);

-- --------------------------------------------------------

--
-- Table structure for table `mobiles`
--

CREATE TABLE `mobiles` (
  `id` int(10) UNSIGNED NOT NULL,
  `number` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `mobiles`
--

INSERT INTO `mobiles` (`id`, `number`, `user_id`, `created_at`, `updated_at`) VALUES
(1, '9810173766', 1, '2019-09-07 10:32:10', '2019-09-07 10:32:10'),
(2, '9841574050', 1, '2019-09-07 10:32:22', '2019-09-07 10:32:22'),
(3, '9841304023', 2, '2019-09-07 10:34:29', '2019-09-07 10:34:29'),
(4, '9841323211', 2, '2019-09-07 10:34:38', '2019-09-07 10:34:38');

-- --------------------------------------------------------

--
-- Table structure for table `passports`
--

CREATE TABLE `passports` (
  `id` int(10) UNSIGNED NOT NULL,
  `number` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `passports`
--

INSERT INTO `passports` (`id`, `number`, `user_id`, `created_at`, `updated_at`) VALUES
(1, 234, 1, '2019-09-08 02:41:53', '2019-09-08 02:41:53'),
(2, 235, 2, '2019-09-08 02:42:03', '2019-09-08 02:42:03');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `body` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `title`, `body`, `created_at`, `updated_at`) VALUES
(1, 'post 1', 'This is post 1', '2019-09-08 01:46:08', '2019-09-08 01:46:08'),
(2, 'post 2', 'This is post 2', '2019-09-08 01:46:16', '2019-09-08 01:46:16');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cost` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `detail` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `title`, `cost`, `detail`, `image`, `user_id`, `created_at`, `updated_at`) VALUES
(2, 'Chicken chilly boneless', '400', 'Chicken chilly are delicious', '3fe59626b5b9d9cceb74431af68d1d3be5c58604.jpg', 2, '2019-09-10 09:53:24', '2019-09-10 09:53:24'),
(5, 'French fries', '285', 'I love french fries', '9ef06bf8b642d0d4f55c76385a5fb2e1e875a738.jpg', 2, '2019-09-10 21:28:07', '2019-09-10 21:28:07'),
(7, 'Pizza', '450', 'Pizza is an italian dish', '954302ce310996398208e83b03121ea81b35d8fe.jpg', 1, '2019-09-11 02:05:10', '2019-09-11 02:05:10');

-- --------------------------------------------------------

--
-- Table structure for table `role_user`
--

CREATE TABLE `role_user` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `role_user`
--

INSERT INTO `role_user` (`id`, `user_id`, `role_id`, `created_at`, `updated_at`) VALUES
(2, 1, 3, '2019-09-07 21:58:40', '2019-09-07 21:58:40'),
(3, 1, 4, '2019-09-07 21:58:46', '2019-09-07 21:58:46'),
(4, 2, 3, '2019-09-07 21:58:59', '2019-09-07 21:58:59'),
(5, 2, 5, '2019-09-07 21:59:04', '2019-09-07 21:59:04');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(10) UNSIGNED NOT NULL,
  `role` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `role`, `created_at`, `updated_at`) VALUES
(3, 'Editor', '2019-09-07 21:54:12', '2019-09-07 21:54:12'),
(4, 'Admin', '2019-09-07 21:54:20', '2019-09-07 21:54:20'),
(5, 'Intern', '2019-09-07 21:54:27', '2019-09-07 21:54:27');

-- --------------------------------------------------------

--
-- Table structure for table `songs`
--

CREATE TABLE `songs` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `artist` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'saramsa', 'ssaramsa@gmail.com', '$2y$10$lVlsiJBcxwmREhYkVc88O.jF52zEXIygCyRDDTZyo.I1DVp7hIp9a', '9ANeYsika6oP8VEbiVjIiwpGcXHHeztQC6uYPFATJF2lnXIRB5L4rv1ePfu7', '2019-09-11 21:47:06', '2019-09-11 21:47:06');

-- --------------------------------------------------------

--
-- Table structure for table `videos`
--

CREATE TABLE `videos` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `videos`
--

INSERT INTO `videos` (`id`, `title`, `url`, `created_at`, `updated_at`) VALUES
(2, 'Video 1', 'www.youtube.com/webfumes', '2019-09-08 01:52:00', '2019-09-08 01:52:00'),
(3, 'Video 2', 'www.facebook.com', '2019-09-08 01:52:14', '2019-09-08 01:52:14');

-- --------------------------------------------------------

--
-- Table structure for table `works`
--

CREATE TABLE `works` (
  `id` int(10) UNSIGNED NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `assignedby` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `works`
--

INSERT INTO `works` (`id`, `description`, `assignedby`, `created_at`, `updated_at`) VALUES
(1, 'Complete Laravel series by webfumes technologies', 'Saramsa P Sherchan', '2019-09-08 03:44:43', '2019-09-08 03:44:43'),
(12, 'Another one', 'Saramsa P Sherchan', '2019-09-09 03:24:43', '2019-09-09 03:24:43');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mobiles`
--
ALTER TABLE `mobiles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `passports`
--
ALTER TABLE `passports`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `role_user`
--
ALTER TABLE `role_user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `songs`
--
ALTER TABLE `songs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `videos`
--
ALTER TABLE `videos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `works`
--
ALTER TABLE `works`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT for table `mobiles`
--
ALTER TABLE `mobiles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `passports`
--
ALTER TABLE `passports`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `role_user`
--
ALTER TABLE `role_user`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `songs`
--
ALTER TABLE `songs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `videos`
--
ALTER TABLE `videos`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `works`
--
ALTER TABLE `works`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;--
-- Database: `inventory`
--
CREATE DATABASE IF NOT EXISTS `inventory` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `inventory`;

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `username` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `username`, `password`, `email`, `created_at`, `updated_at`) VALUES
(1, 'Admin', '$2y$10$C03lm2XtYLkM6YovhPh6Seu9IuCl3gUBpEafAt1XcaC7TKkFd.F2S', 'Admin@gmail.com', '2019-11-07 08:24:57', '2019-11-07 08:25:01');

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `brand_name` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `brand_desc` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`id`, `brand_name`, `brand_desc`, `created_at`, `updated_at`) VALUES
(1, 'Asus', 'All the electronic gadgets related to asus.', '2019-11-08 00:18:06', '2019-11-08 00:18:06'),
(2, 'Samsung', 'All the electronic appliances related to Samsung company it includes variety of home appliances', '2019-11-08 00:24:11', '2019-11-08 01:14:12'),
(3, 'Acer', 'All the electronic appliances related to acer brand', '2019-11-08 01:15:12', '2019-11-08 01:15:12');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `categ_name` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `categ_desc` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `categ_name`, `categ_desc`, `created_at`, `updated_at`) VALUES
(1, 'Mobile & Tablets', 'Include cell phones and tablets ranging from various prices and companies.', NULL, NULL),
(2, 'Tvs', 'Includes wide range of television sets from led,LCD to OLED etc.', '2019-11-07 23:02:27', '2019-11-07 23:02:27'),
(3, 'Laptop', 'Laptop of various companies with wide range of prices such as Asus,Acer ,Samsung etc', '2019-11-07 23:12:55', '2019-11-07 23:48:23');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `customer_name` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_address` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contactno` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `customer_name`, `customer_address`, `contactno`, `created_at`, `updated_at`) VALUES
(1, 'Rishab Shrestha', 'Kapan,Kathmandu', '9846554987', '2019-11-11 04:24:32', '2019-11-11 04:24:32'),
(2, 'Saiyam Gurung', 'Baneshwor', '9813065798', '2019-11-11 04:24:44', '2019-11-11 04:24:44'),
(3, 'Sabin Kayastha', 'Asan', '9841567890', '2019-11-11 04:25:19', '2019-11-11 04:25:29');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_11_07_134527_create_admins_table', 1),
(5, '2019_11_08_041946_create_categories_table', 2),
(6, '2019_11_08_053422_create_brands_table', 3),
(8, '2019_11_08_070127_create_products_table', 4),
(9, '2019_11_09_161346_create_suppliers_table', 5),
(11, '2019_11_10_114732_create_stocks_table', 6),
(12, '2019_11_10_160456_create_stock_availables_table', 7),
(14, '2019_11_11_084529_create_customers_table', 8),
(15, '2019_11_11_095806_create_stock__purchaseds_table', 9);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_name` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_desc` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_price` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_image` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_id` bigint(20) UNSIGNED NOT NULL,
  `brand_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `product_name`, `product_desc`, `product_price`, `product_image`, `category_id`, `brand_id`, `created_at`, `updated_at`) VALUES
(1, 'Asus ZenFone Max M2', 'The Asus ZenFone Max M2 isn\'t a replacement for the ZenFone Max M1, but slots above it.', '24000', '43d11012a09e172878d2ddf5caec867950fac871.jpg', 1, 1, '2019-11-09 08:05:06', '2019-11-11 22:38:53'),
(2, 'Samsung 55\" Class The Frame QLED Smart 4K UHD TV (2019)', 'Elevate your viewing experience with this 55-inch Samsung smart TV awesome', '74000', 'e52de73348ca17e0a003e2c9554bc2c0b60c3758.jpg', 1, 1, '2019-11-09 08:07:18', '2019-11-11 10:16:21');

-- --------------------------------------------------------

--
-- Table structure for table `stock__purchaseds`
--

CREATE TABLE `stock__purchaseds` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `customer_id` bigint(20) UNSIGNED NOT NULL,
  `price` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `due_amount` varchar(141) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pay_mode` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `stock__purchaseds`
--

INSERT INTO `stock__purchaseds` (`id`, `product_id`, `customer_id`, `price`, `quantity`, `total`, `due_amount`, `payment`, `status`, `pay_mode`, `created_at`, `updated_at`) VALUES
(1, 1, 1, '24000', '50', '1200000', NULL, '1200000', 'Paid', 'Cash', '2019-11-11 22:21:43', '2019-11-11 22:21:43');

-- --------------------------------------------------------

--
-- Table structure for table `stock_availables`
--

CREATE TABLE `stock_availables` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `buying_price` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `selling_price` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `stock_quantity` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `stock_availables`
--

INSERT INTO `stock_availables` (`id`, `product_id`, `buying_price`, `selling_price`, `stock_quantity`, `created_at`, `updated_at`) VALUES
(1, 1, '23000', '24000', '160', '2019-11-11 22:18:48', '2019-11-11 22:38:53');

-- --------------------------------------------------------

--
-- Table structure for table `stocks`
--

CREATE TABLE `stocks` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `available_stock` varchar(141) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `supplier_id` bigint(20) UNSIGNED NOT NULL,
  `buying_price` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `selling_price` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `due_amount` varchar(141) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pay_mode` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `stocks`
--

INSERT INTO `stocks` (`id`, `product_id`, `available_stock`, `supplier_id`, `buying_price`, `selling_price`, `quantity`, `total`, `due_amount`, `payment`, `status`, `pay_mode`, `created_at`, `updated_at`) VALUES
(1, 1, NULL, 1, '23000', '24000', '120', '2300000', NULL, '2300000', 'Paid', 'Cash', '2019-11-11 22:18:48', '2019-11-11 22:20:50'),
(2, 1, NULL, 3, '23000', '24000', '40', '960000', NULL, '960000', 'Paid', 'Cash', '2019-11-11 22:38:53', '2019-11-11 22:38:53');

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

CREATE TABLE `suppliers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `supplier_name` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `supplier_address` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contactno` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `suppliers`
--

INSERT INTO `suppliers` (`id`, `supplier_name`, `supplier_address`, `contactno`, `created_at`, `updated_at`) VALUES
(1, 'Ramesh Kharel', 'Baluwatar,Kathmandu', '9810298765', NULL, NULL),
(3, 'Binam Upadhya', 'Baneshwor,Kathmandu', '9846554986', NULL, '2019-11-10 05:49:31');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `products_category_id_foreign` (`category_id`),
  ADD KEY `products_brand_id_foreign` (`brand_id`);

--
-- Indexes for table `stock__purchaseds`
--
ALTER TABLE `stock__purchaseds`
  ADD PRIMARY KEY (`id`),
  ADD KEY `stock__purchaseds_product_id_foreign` (`product_id`),
  ADD KEY `stock__purchaseds_customer_id_foreign` (`customer_id`);

--
-- Indexes for table `stock_availables`
--
ALTER TABLE `stock_availables`
  ADD PRIMARY KEY (`id`),
  ADD KEY `stock_availables_product_id_foreign` (`product_id`);

--
-- Indexes for table `stocks`
--
ALTER TABLE `stocks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `stocks_product_id_foreign` (`product_id`),
  ADD KEY `stocks_supplier_id_foreign` (`supplier_id`);

--
-- Indexes for table `suppliers`
--
ALTER TABLE `suppliers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `stock__purchaseds`
--
ALTER TABLE `stock__purchaseds`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `stock_availables`
--
ALTER TABLE `stock_availables`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `stocks`
--
ALTER TABLE `stocks`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `suppliers`
--
ALTER TABLE `suppliers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_brand_id_foreign` FOREIGN KEY (`brand_id`) REFERENCES `brands` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `products_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `stock__purchaseds`
--
ALTER TABLE `stock__purchaseds`
  ADD CONSTRAINT `stock__purchaseds_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `stock__purchaseds_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `stock_availables`
--
ALTER TABLE `stock_availables`
  ADD CONSTRAINT `stock_availables_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `stocks`
--
ALTER TABLE `stocks`
  ADD CONSTRAINT `stocks_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `stocks_supplier_id_foreign` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE CASCADE;
--
-- Database: `loginsystem`
--
CREATE DATABASE IF NOT EXISTS `loginsystem` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `loginsystem`;

-- --------------------------------------------------------

--
-- Table structure for table `userprofile`
--

CREATE TABLE `userprofile` (
  `id` int(11) NOT NULL,
  `fullname` varchar(244) NOT NULL,
  `title` varchar(244) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `content` varchar(244) DEFAULT NULL,
  `created_at` date DEFAULT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userprofile`
--

INSERT INTO `userprofile` (`id`, `fullname`, `title`, `user_id`, `content`, `created_at`, `image`) VALUES
(6, 'Sankalpa Sherchan', 'Chicken chilly', 2, 'I love chicken chilly', '2019-06-24', '5d107eecafbad7.71096502.jpg'),
(7, 'BInam Upadhya', 'French fries', 1, 'I do like the crispiness of the french fries i reallly do and i like to share it with people', '2019-06-24', '5d1080178a83e0.86645050.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `user_first` varchar(256) NOT NULL,
  `user_last` varchar(256) NOT NULL,
  `user_email` varchar(256) NOT NULL,
  `user_uid` varchar(256) NOT NULL,
  `user_pwd` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `user_first`, `user_last`, `user_email`, `user_uid`, `user_pwd`) VALUES
(1, 'BInam', 'Upadhya', 'Binam_425@gmail.com', 'Binam425', '$2y$10$ftN1CTWk4HNYQQV3M3NTL.hwwU./i9jye/JR9PhYAcJKwex8KUi5e'),
(2, 'Sankalpa', 'Sherchan', 'sankalapa_sherchan@gmail.com', 'Sankalpa007', '$2y$10$a1Vk2rHiCX3BlxCu7mxC/OJyNhxQdtLvb2QsT7b7JW8iGq0bSRYEC');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `userprofile`
--
ALTER TABLE `userprofile`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `userprofile`
--
ALTER TABLE `userprofile`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;--
-- Database: `mantra_thakali`
--
CREATE DATABASE IF NOT EXISTS `mantra_thakali` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `mantra_thakali`;

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `job_title` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `name`, `email`, `job_title`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(3, 'Saramsa Sherchan', 'ssaramsa@gmail.com', 'CEO', '$2y$10$jZ2gVD8Mw5mumh6js2TTQuVzz2MSyKsRtmPL.SJdSviOrSGw5JzG2', 'aLLgRRfjGA4vJhDeI4FO2BpUHEG1tYXttzNZOsKS3Otg3tTu31dSVZjoeOks', '2019-09-29 06:57:15', '2019-09-29 06:57:15');

-- --------------------------------------------------------

--
-- Table structure for table `carts`
--

CREATE TABLE `carts` (
  `id` int(10) UNSIGNED NOT NULL,
  `product_id` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `session_id` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Image` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `qty` int(11) NOT NULL,
  `cost` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `carts`
--

INSERT INTO `carts` (`id`, `product_id`, `session_id`, `title`, `Image`, `qty`, `cost`, `created_at`, `updated_at`) VALUES
(1, '7', 'OQl17o', 'Thakali Thali', '', 1, '285', '2019-03-18 02:32:08', '2019-03-18 02:32:08'),
(2, '7', 'OQl17o', 'Thakali Thali', '', 1, '285', '2019-03-18 02:32:28', '2019-03-18 02:32:28'),
(3, '7', 'OQl17o', 'Thakali Thali', '', 1, '285', '2019-03-18 02:32:56', '2019-03-18 02:32:56'),
(4, '9', 'OQl17o', 'French fries', '', 1, '80', '2019-03-18 02:38:29', '2019-03-18 02:38:29'),
(5, '10', 'OQl17o', 'Chips', '', 1, '285', '2019-03-18 02:40:05', '2019-03-18 02:40:05'),
(6, '9', 'OQl17o', 'French fries', '', 1, '80', '2019-03-18 02:41:56', '2019-03-18 02:41:56'),
(7, '7', 'OQl17o', 'Thakali Thali', '', 1, '285', '2019-03-18 02:42:48', '2019-03-18 02:42:48'),
(8, '9', 'OQl17o', 'French fries', '', 1, '80', '2019-03-18 02:51:21', '2019-03-18 02:51:21'),
(10, '10', 'NcbI9m', 'Chips', '', 1, '285', '2019-03-19 01:40:48', '2019-03-19 01:40:48'),
(11, '10', 'NcbI9m', 'Chips', '', 1, '285', '2019-03-19 01:41:31', '2019-03-19 01:41:31'),
(13, '9', 'NcbI9m', 'French fries', '', 1, '80', '2019-03-19 01:51:33', '2019-03-19 01:51:33'),
(17, '10', '5X2JN6', 'Chips', '', 3, '1710', '2019-03-19 04:18:20', '2019-03-19 04:19:52'),
(18, '10', '5X2JN6', 'Chips', 'c9ab5547e0b166a453fbbe279bce1b48ea299f2f.jpg', 1, '285', '2019-03-19 04:28:18', '2019-03-19 04:28:18'),
(19, '10', 'buydJP', 'Chips', 'c9ab5547e0b166a453fbbe279bce1b48ea299f2f.jpg', 1, '570', '2019-03-21 02:20:35', '2019-03-21 02:21:13'),
(20, '7', 'buydJP', 'Thakali Thali', '0bbacfb50a469a6f0bb3908717df572a4c7782f5.jpg', 1, '285', '2019-03-21 02:20:48', '2019-03-21 02:20:48'),
(21, '9', 'MQes5X', 'French fries', '8eb43a3b37ee77c454d7de7f8302b1885e717e00.jpg', 2, '160', '2019-03-21 19:50:45', '2019-03-21 19:50:56'),
(22, '10', 'MQes5X', 'Chips', 'c9ab5547e0b166a453fbbe279bce1b48ea299f2f.jpg', 1, '285', '2019-03-21 19:51:09', '2019-03-21 19:51:09'),
(23, '10', 'yaPSIT', 'Chips', 'c9ab5547e0b166a453fbbe279bce1b48ea299f2f.jpg', 3, '855', '2019-03-24 03:24:52', '2019-03-24 03:27:27'),
(24, '9', 'yaPSIT', 'French fries', '8eb43a3b37ee77c454d7de7f8302b1885e717e00.jpg', 1, '80', '2019-03-24 03:25:49', '2019-03-24 03:31:26'),
(25, '7', 'yaPSIT', 'Thakali Thali', '0bbacfb50a469a6f0bb3908717df572a4c7782f5.jpg', 1, '285', '2019-03-24 03:28:22', '2019-03-24 03:28:36'),
(26, '7', 'yaPSIT', 'Thakali Thali', '0bbacfb50a469a6f0bb3908717df572a4c7782f5.jpg', 1, '285', '2019-03-24 03:29:55', '2019-03-24 03:29:55');

-- --------------------------------------------------------

--
-- Table structure for table `catagories`
--

CREATE TABLE `catagories` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `details` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `catagories`
--

INSERT INTO `catagories` (`id`, `title`, `details`, `created_at`, `updated_at`) VALUES
(4, 'Pasrty', 'jdlkasjlkdjas', '2019-01-08 02:15:54', '2019-01-08 02:15:54'),
(5, 'Desk', 'bkjdakjbkas', '2019-01-08 02:16:47', '2019-01-08 02:16:47'),
(6, 'Jhandu bam', 'dlkaldjaslkjdkasljdlasj', '2019-01-08 02:49:32', '2019-01-08 02:49:32'),
(7, 'Tea bag', 'I am a tea bag3', '2019-01-13 01:45:04', '2019-01-14 01:46:09'),
(8, 'jnj', 'bbjhb', '2019-01-14 01:46:01', '2019-01-14 01:46:01');

-- --------------------------------------------------------

--
-- Table structure for table `image_uploads`
--

CREATE TABLE `image_uploads` (
  `id` int(10) UNSIGNED NOT NULL,
  `filename` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `image_uploads`
--

INSERT INTO `image_uploads` (`id`, `filename`, `created_at`, `updated_at`) VALUES
(1, '26.JPG', '2019-01-30 03:37:23', '2019-01-30 03:37:23'),
(2, '12.JPG', '2019-01-30 03:49:18', '2019-01-30 03:49:18'),
(3, '13.JPG', '2019-01-30 03:49:19', '2019-01-30 03:49:19'),
(4, '30.JPG', '2019-01-30 03:52:20', '2019-01-30 03:52:20');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_01_03_075430_create_catagories_table', 2),
(5, '2014_10_12_000000_create_users_table', 4),
(6, '2019_01_14_073517_create_products_table', 5),
(7, '2019_01_30_075805_create_image_uploads_table', 6),
(8, '2019_03_18_064409_create_carts_table', 7),
(9, '2019_09_29_113205_create_admins_table', 8);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cost` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `detail` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `title`, `cost`, `detail`, `image`, `created_at`, `updated_at`) VALUES
(7, 'Thakali Thali', '285', 'i am red', '0bbacfb50a469a6f0bb3908717df572a4c7782f5.jpg', '2019-01-17 02:03:51', '2019-01-23 01:48:29'),
(9, 'French fries', '80', 'bhjhrvfrmn dxnma', '8eb43a3b37ee77c454d7de7f8302b1885e717e00.jpg', '2019-01-17 02:08:01', '2019-01-21 01:56:59'),
(10, 'Chips', '285', 'wqdnm we dew', 'c9ab5547e0b166a453fbbe279bce1b48ea299f2f.jpg', '2019-01-17 02:08:52', '2019-01-17 02:08:52'),
(11, 'Chee', '50', '<h1>Cheesbal of <strong><em>Chaduary group</em></strong>&nbsp;</h1>', '0343a953f24c01a4985eae08dc204bffc9a23f4e.JPG', '2019-01-28 01:44:13', '2019-01-28 01:44:13');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'saramsa Prasad Sherchan', 'sherchan_hari@live.com', '$2y$10$2ixQiH5mLbhFj4Trj7BsAuhy.jYaADMfn9/NKLhn18TOCFDbuajkq', 'NHHu1Zs0eAFngindd9nO7GKkHAOKMisMVOicrNi1xofK4BwC4LgIU4yCQt7s', '2019-01-14 01:59:52', '2019-01-14 01:59:52'),
(2, 'Jenish', 'Jenish@gmail.com', '$2y$10$PjOgwXDAHhtLUI6lFft18uijMwJbkhRgzdsHf4Cdp2mUogFdOB0kq', NULL, '2019-09-01 08:54:19', '2019-09-01 08:54:19');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `admins_email_unique` (`email`);

--
-- Indexes for table `carts`
--
ALTER TABLE `carts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `catagories`
--
ALTER TABLE `catagories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `image_uploads`
--
ALTER TABLE `image_uploads`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `carts`
--
ALTER TABLE `carts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
--
-- AUTO_INCREMENT for table `catagories`
--
ALTER TABLE `catagories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `image_uploads`
--
ALTER TABLE `image_uploads`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;--
-- Database: `mantra_thakola`
--
CREATE DATABASE IF NOT EXISTS `mantra_thakola` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `mantra_thakola`;

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(10) UNSIGNED NOT NULL,
  `username` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `username`, `password`, `status`, `created_at`, `updated_at`) VALUES
(1, 'admin', '0192023a7bbd73250516f069df18b500', 1, '2019-05-01 14:55:13', '2019-05-01 14:55:26');

-- --------------------------------------------------------

--
-- Table structure for table `carts`
--

CREATE TABLE `carts` (
  `id` int(10) UNSIGNED NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_name` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` double(8,2) NOT NULL,
  `quantity` int(11) NOT NULL,
  `user_email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `session_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `carts`
--

INSERT INTO `carts` (`id`, `product_id`, `product_name`, `price`, `quantity`, `user_email`, `session_id`, `created_at`, `updated_at`) VALUES
(7, 32, 'Chicken momo', 250.00, 100, 'ssaramsa@gmail.com', 'aVf88jEc0BAfdhEr4v9kw6Lq8F2AEZfoKw96jKRm', NULL, NULL),
(9, 32, 'Chicken momo', 250.00, 1, '', 'zBhjnu0LKLrcipJly0Kc6wOfG92DF3J7nI0fRCAD', NULL, NULL),
(11, 34, 'Chicken tandoori', 600.00, 6, '', 'ZmkYkoghIasqKQNfuttBlL2uLMSZBagiYMi2ywRM', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `parent_id`, `name`, `description`, `url`, `status`, `remember_token`, `created_at`, `updated_at`) VALUES
(7, 0, 'Vegetarian', 'Vegetarian items are included', 'Vegetarian', 1, NULL, '2019-03-26 21:13:05', '2019-04-03 10:29:19'),
(8, 0, 'Drinks/Beverages', 'Includes beverages from soft to hard drinks', 'Beverages', 1, NULL, '2019-03-26 21:35:02', '2019-03-26 21:35:02'),
(11, 8, 'Soft drinks', 'Include soft beverages such as coke, fanta etc.', 'Soft drinks', 1, NULL, '2019-03-26 22:34:59', '2019-03-26 22:34:59'),
(13, 8, 'Hard drinks', 'Includes liquor and other spirited drinks.', 'Hard drinks', 1, NULL, '2019-03-27 03:59:23', '2019-03-27 03:59:23'),
(14, 0, 'Non-vegetarian', 'Non-veg items are included', 'Non-vegetarian', 1, NULL, '2019-03-29 22:32:49', '2019-04-02 06:03:49'),
(15, 14, 'chicken', 'Chicken items are include', 'chicken', 1, NULL, '2019-03-29 22:33:51', '2019-03-29 22:33:51'),
(18, 14, 'mutton', 'mutton items are included', 'mutton', 1, NULL, '2019-03-30 04:10:16', '2019-03-30 04:10:16'),
(19, 7, 'Vegetarian', 'Vegetarian items are include', 'Veg', 1, NULL, '2019-04-02 07:07:35', '2019-04-02 07:53:41'),
(23, 14, 'Pork/Pig', 'Pork is delicious', 'Pork', 1, NULL, '2019-05-07 23:53:46', '2019-05-07 23:53:46');

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE `contacts` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobileNo` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `contacts`
--

INSERT INTO `contacts` (`id`, `name`, `email`, `mobileNo`, `message`, `created_at`, `updated_at`) VALUES
(5, 'Jenis Gurung', 'Ghale_hancy@gmail.com', '9837263729', 'Place is really nice and food is awesome', '2019-03-15 21:57:44', '2019-03-16 01:10:00'),
(6, 'Saramsa Prasad Sherchan', 'SSaramsa@gmail.com', '9836257972', 'Authentic thakali cuisine with great taste', '2019-03-16 03:13:01', '2019-03-16 03:13:01'),
(7, 'Anish Magar', 'Magar_anish@gmail.com', '9835467637', 'Food was tasty and healthy aswell', '2019-03-31 01:24:49', '2019-03-31 01:24:49');

-- --------------------------------------------------------

--
-- Table structure for table `delievery_addresses`
--

CREATE TABLE `delievery_addresses` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_email` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobileno` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pincode` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `delievery_addresses`
--

INSERT INTO `delievery_addresses` (`id`, `user_id`, `user_email`, `name`, `address`, `city`, `mobileno`, `pincode`, `created_at`, `updated_at`) VALUES
(1, 30, 'Binam_425@yopmail.com', 'Binam', 'Bhairabtole', 'Pokhara', '9810175677', '345678', '2019-05-05 05:17:39', '2019-05-29 02:59:21'),
(2, 31, 'dambar@yopmail.com', 'dambr', 'fulbari', 'Pokhara', '9826192329', '123456', '2019-05-06 23:25:06', '2019-05-06 23:25:06'),
(3, 33, 'ssaramsa@gmail.com', 'Saramsa425', 'Ranipauwa', 'Pokhara', '9810173766', '234567', '2019-05-08 10:18:59', '2019-05-29 23:33:57');

-- --------------------------------------------------------

--
-- Table structure for table `foods`
--

CREATE TABLE `foods` (
  `id` int(10) UNSIGNED NOT NULL,
  `FoodName` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Foodcost` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Fooddetail` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Foodimage` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `foods`
--

INSERT INTO `foods` (`id`, `FoodName`, `Foodcost`, `Fooddetail`, `Foodimage`, `created_at`, `updated_at`) VALUES
(2, 'French fries', '140', 'Fried potato sticks served with tomato sauce and mayonnaise.', '36bf27fb8cdbedddd408a47c43b385cfb3a22bdd.jpg', '2019-03-20 23:19:09', '2019-03-21 01:32:16'),
(3, 'Chicken chilly', '285', 'Marinated chicken with tangy flavor, spicy taste', 'fe7b4f3f2721a4edec8ca33fbe37c28b479167d6.jpg', '2019-03-21 00:46:54', '2019-03-21 00:46:54'),
(4, 'Pangra Fry', '300', 'Pangra fry is one of our special dish providing mouth watering taste and flavor to our customers.', 'd6f636eed301604ce464184373b2e09174c5fe16.jpg', '2019-03-22 07:31:14', '2019-03-22 07:31:14'),
(5, 'Chicken Momo', '200', 'Tasty and juicy chicken momo', 'c073aae4ffacf362ea0c85b1cc69f094902194c1.jpg', '2019-03-22 07:31:50', '2019-03-22 07:31:50'),
(6, 'Thakali Thali', '400', 'Authentic thakali thali served with ingredients from mustang', '43d9fa04be58b45318bb8709d350364d6b04b33a.jpg', '2019-03-22 07:34:11', '2019-03-22 07:34:11'),
(7, 'Kanchambha', '250', 'Thakali dish made with flour and ghee,', 'be4f1c6435a9503d61d5d5329be42b7fae022d1d.jpg', '2019-03-22 07:34:42', '2019-03-22 07:34:42');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_03_15_074203_create_contacts_table', 2),
(4, '2019_03_16_091333_create_reservations_table', 3),
(5, '2019_03_21_041923_create_foods_table', 4),
(6, '2019_03_26_062910_create_categories_table', 5),
(7, '2019_03_27_064915_create_products_table', 6),
(8, '2019_04_04_153130_create_carts_table', 7),
(9, '2019_04_13_072844_create_delievery_addresses_table', 8),
(10, '2019_04_17_064207_create_orders_table', 9),
(11, '2019_04_17_070037_create_orders_products_table', 10),
(12, '2019_04_17_132119_create_order_products_table', 11),
(14, '2019_05_01_144955_create_admins_table', 12);

-- --------------------------------------------------------

--
-- Table structure for table `order_products`
--

CREATE TABLE `order_products` (
  `id` int(10) UNSIGNED NOT NULL,
  `order_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_qty` int(11) NOT NULL,
  `price` double(8,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `order_products`
--

INSERT INTO `order_products` (`id`, `order_id`, `user_id`, `product_id`, `product_name`, `product_qty`, `price`, `created_at`, `updated_at`) VALUES
(1, 1, 30, 36, 'Mutton  set', 7, 500.00, '2019-05-05 05:17:48', '2019-05-05 05:17:48'),
(2, 2, 31, 30, 'French Fries', 4, 250.00, '2019-05-06 23:25:19', '2019-05-06 23:25:19'),
(3, 3, 30, 36, 'Mutton  set', 1, 500.00, '2019-05-07 01:17:56', '2019-05-07 01:17:56'),
(4, 5, 30, 36, 'Mutton  set', 3, 500.00, '2019-05-07 01:20:00', '2019-05-07 01:20:00'),
(5, 7, 33, 34, 'Chicken tandoori', 3, 600.00, '2019-05-08 10:39:38', '2019-05-08 10:39:38'),
(6, 8, 33, 36, 'Mutton  set', 4, 500.00, '2019-05-08 11:29:57', '2019-05-08 11:29:57'),
(7, 9, 33, 32, 'Chicken momo', 7, 250.00, '2019-05-16 22:46:18', '2019-05-16 22:46:18'),
(8, 10, 33, 31, 'Kanchambha', 1, 350.00, '2019-05-16 23:32:19', '2019-05-16 23:32:19'),
(9, 11, 30, 32, 'Chicken momo', 1, 250.00, '2019-05-29 01:44:50', '2019-05-29 01:44:50'),
(10, 11, 30, 34, 'Chicken tandoori', 1, 600.00, '2019-05-29 01:44:50', '2019-05-29 01:44:50'),
(11, 12, 30, 37, 'Mutton chop', 1, 400.00, '2019-05-29 02:58:25', '2019-05-29 02:58:25'),
(12, 13, 30, 36, 'Mutton  set', 1, 500.00, '2019-05-29 02:59:27', '2019-05-29 02:59:27'),
(13, 14, 33, 35, 'Mutton Sekuwa', 1, 400.00, '2019-05-29 03:30:34', '2019-05-29 03:30:34'),
(14, 15, 33, 35, 'Mutton Sekuwa', 1, 400.00, '2019-05-29 03:30:57', '2019-05-29 03:30:57'),
(15, 16, 33, 35, 'Mutton Sekuwa', 1, 400.00, '2019-05-29 03:32:16', '2019-05-29 03:32:16'),
(16, 17, 33, 36, 'Mutton  set', 1, 500.00, '2019-05-29 05:27:19', '2019-05-29 05:27:19'),
(17, 18, 33, 36, 'Mutton  set', 1, 500.00, '2019-05-29 05:29:02', '2019-05-29 05:29:02'),
(18, 19, 33, 36, 'Mutton  set', 1, 500.00, '2019-05-29 05:29:36', '2019-05-29 05:29:36'),
(19, 20, 33, 32, 'Chicken momo', 1, 250.00, '2019-05-29 06:09:58', '2019-05-29 06:09:58'),
(20, 22, 33, 31, 'Kanchambha', 2, 350.00, '2019-05-29 06:35:25', '2019-05-29 06:35:25'),
(21, 23, 33, 30, 'French Fries', 1, 250.00, '2019-05-29 21:31:52', '2019-05-29 21:31:52'),
(22, 24, 33, 32, 'Chicken momo', 1, 250.00, '2019-05-29 21:37:19', '2019-05-29 21:37:19'),
(23, 25, 33, 32, 'Chicken momo', 1, 250.00, '2019-05-29 21:40:53', '2019-05-29 21:40:53'),
(24, 26, 33, 32, 'Chicken momo', 1, 250.00, '2019-05-29 21:45:02', '2019-05-29 21:45:02'),
(25, 27, 33, 30, 'French Fries', 1, 250.00, '2019-05-29 21:48:27', '2019-05-29 21:48:27'),
(26, 28, 33, 36, 'Mutton  set', 2, 500.00, '2019-05-29 21:56:33', '2019-05-29 21:56:33'),
(27, 29, 33, 35, 'Mutton Sekuwa', -1, 400.00, '2019-05-29 23:33:19', '2019-05-29 23:33:19');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_email` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobileno` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pincode` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `discount_amount` double(8,2) NOT NULL,
  `grand_total` double(8,2) NOT NULL,
  `order_status` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_method` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `user_email`, `name`, `address`, `city`, `mobileno`, `pincode`, `discount_amount`, `grand_total`, `order_status`, `payment_method`, `created_at`, `updated_at`) VALUES
(1, 30, 'Binam_425@yopmail.com', 'Binam', 'Bhairabtole', 'Pokhara', '9810175677', '345678', 0.00, 3150.00, 'Pending', 'COD', '2019-05-05 05:17:48', '2019-06-22 06:48:31'),
(2, 31, 'dambar@yopmail.com', 'dambr', 'fulbari', 'Pokhara', '9826192329', '123456', 0.00, 1000.00, 'Delievered', 'COD', '2019-05-06 23:25:19', '2019-05-08 02:47:02'),
(3, 30, 'Binam_425@yopmail.com', 'Binam', 'Bhairabtole', 'Pokhara', '9810175677', '345678', 0.00, 500.00, 'New', 'khalti', '2019-05-07 01:17:56', '2019-05-07 01:17:56'),
(5, 30, 'Binam_425@yopmail.com', 'Binam', 'Bhairabtole', 'Pokhara', '9810175677', '345678', 0.00, 1500.00, 'New', 'khalti', '2019-05-07 01:20:00', '2019-05-07 01:20:00'),
(7, 33, 'ssaramsa@gmail.com', 'Saramsa425', 'Ranipauwa', 'Pokhara', '9810173766', '234567', 0.00, 1800.00, 'New', 'COD', '2019-05-08 10:39:38', '2019-05-08 10:39:38'),
(8, 33, 'ssaramsa@gmail.com', 'Saramsa425', 'Ranipauwa', 'Pokhara', '9810173766', '234567', 0.00, 2000.00, 'In Process', 'COD', '2019-05-08 11:29:57', '2019-05-08 12:38:35'),
(9, 33, 'ssaramsa@gmail.com', 'Saramsa425', 'Ranipauwa', 'Pokhara', '9810173766', '234567', 0.00, 1750.00, 'New', 'COD', '2019-05-16 22:46:17', '2019-05-16 22:46:17'),
(10, 33, 'ssaramsa@gmail.com', 'Saramsa425', 'Ranipauwa', 'Pokhara', '9810173766', '234567', 0.00, 350.00, 'New', 'khalti', '2019-05-16 23:32:18', '2019-05-16 23:32:18'),
(11, 30, 'Binam_425@yopmail.com', 'Binam', 'Bhairabtole', 'Pokhara', '9810175677', '345678', 0.00, 850.00, 'New', 'khalti', '2019-05-29 01:44:50', '2019-05-29 01:44:50'),
(12, 30, 'Binam_425@yopmail.com', 'Binam', 'Bhairabtole', 'Pokhara', '9810175677', '345678', 0.00, 400.00, 'New', 'khalti', '2019-05-29 02:58:25', '2019-05-29 02:58:25'),
(13, 30, 'Binam_425@yopmail.com', 'Binam', 'Bhairabtole', 'Pokhara', '9810175677', '345678', 0.00, 500.00, 'New', 'khalti', '2019-05-29 02:59:27', '2019-05-29 02:59:27'),
(14, 33, 'ssaramsa@gmail.com', 'Saramsa425', 'Ranipauwa', 'Pokhara', '9810173766', '234567', 0.00, 400.00, 'New', 'khalti', '2019-05-29 03:30:33', '2019-05-29 03:30:33'),
(15, 33, 'ssaramsa@gmail.com', 'Saramsa425', 'Ranipauwa', 'Pokhara', '9810173766', '234567', 0.00, 400.00, 'New', 'khalti', '2019-05-29 03:30:57', '2019-05-29 03:30:57'),
(16, 33, 'ssaramsa@gmail.com', 'Saramsa425', 'Ranipauwa', 'Pokhara', '9810173766', '234567', 0.00, 400.00, 'New', 'khalti', '2019-05-29 03:32:16', '2019-05-29 03:32:16'),
(17, 33, 'ssaramsa@gmail.com', 'Saramsa425', 'Ranipauwa', 'Pokhara', '9810173766', '234567', 0.00, 500.00, 'New', 'khalti', '2019-05-29 05:27:19', '2019-05-29 05:27:19'),
(18, 33, 'ssaramsa@gmail.com', 'Saramsa425', 'Ranipauwa', 'Pokhara', '9810173766', '234567', 0.00, 500.00, 'New', 'khalti', '2019-05-29 05:29:02', '2019-05-29 05:29:02'),
(19, 33, 'ssaramsa@gmail.com', 'Saramsa425', 'Ranipauwa', 'Pokhara', '9810173766', '234567', 0.00, 500.00, 'New', 'khalti', '2019-05-29 05:29:36', '2019-05-29 05:29:36'),
(20, 33, 'ssaramsa@gmail.com', 'Saramsa425', 'Ranipauwa', 'Pokhara', '9810173766', '234567', 0.00, 250.00, 'New', 'khalti', '2019-05-29 06:09:58', '2019-05-29 06:09:58'),
(21, 33, 'ssaramsa@gmail.com', 'Saramsa425', 'Ranipauwa', 'Pokhara', '9810173766', '234567', 0.00, 250.00, 'New', 'khalti', '2019-05-29 06:10:08', '2019-05-29 06:10:08'),
(22, 33, 'ssaramsa@gmail.com', 'Saramsa425', 'Ranipauwa', 'Pokhara', '9810173766', '234567', 0.00, 700.00, 'New', 'khalti', '2019-05-29 06:35:25', '2019-05-29 06:35:25'),
(23, 33, 'ssaramsa@gmail.com', 'Saramsa425', 'Ranipauwa', 'Pokhara', '9810173766', '234567', 0.00, 250.00, 'New', 'COD.', '2019-05-29 21:31:52', '2019-05-29 21:31:52'),
(24, 33, 'ssaramsa@gmail.com', 'Saramsa425', 'Ranipauwa', 'Pokhara', '9810173766', '234567', 0.00, 250.00, 'New', 'Khalti payment.', '2019-05-29 21:37:19', '2019-05-29 21:37:19'),
(25, 33, 'ssaramsa@gmail.com', 'Saramsa425', 'Ranipauwa', 'Pokhara', '9810173766', '234567', 0.00, 250.00, 'New', 'Khalti payment.', '2019-05-29 21:40:53', '2019-05-29 21:40:53'),
(26, 33, 'ssaramsa@gmail.com', 'Saramsa425', 'Ranipauwa', 'Pokhara', '9810173766', '234567', 0.00, 250.00, 'New', 'Khalti payment.', '2019-05-29 21:45:02', '2019-05-29 21:45:02'),
(27, 33, 'ssaramsa@gmail.com', 'Saramsa425', 'Ranipauwa', 'Pokhara', '9810173766', '234567', 0.00, 250.00, 'New', 'Khalti payment.', '2019-05-29 21:48:27', '2019-05-29 21:48:27'),
(28, 33, 'ssaramsa@gmail.com', 'Saramsa425', 'Ranipauwa', 'Pokhara', '9810173766', '234567', 0.00, 1000.00, 'New', 'Khalti payment.', '2019-05-29 21:56:33', '2019-05-29 21:56:33'),
(29, 33, 'ssaramsa@gmail.com', 'Saramsa425', 'Ranipauwa', 'Pokhara', '9810173766', '234567', 0.00, -400.00, 'New', 'COD.', '2019-05-29 23:33:19', '2019-05-29 23:33:19');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(10) UNSIGNED NOT NULL,
  `category_id` int(11) NOT NULL,
  `product_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` double(8,2) NOT NULL,
  `image` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `category_id`, `product_name`, `description`, `price`, `image`, `created_at`, `updated_at`) VALUES
(29, 19, 'Aloo dhum', 'Aloo dhum is a pcickle potato', 250.00, '94753.jpg', '2019-04-02 07:25:03', '2019-04-02 21:20:45'),
(30, 19, 'French Fries', 'Cripsy fried potato sticks served with sauce and mayonise', 250.00, '4536.jpg', '2019-04-02 07:34:54', '2019-04-02 07:34:54'),
(31, 19, 'Kanchambha', 'Kanchambha is a traditonal thakali dish', 350.00, '12987.jpg', '2019-04-02 07:37:23', '2019-04-02 07:37:23'),
(32, 15, 'Chicken momo', 'juicy fresh cooked chicken momo', 250.00, '18120.jpg', '2019-04-02 07:49:07', '2019-04-02 07:49:07'),
(33, 15, 'Chicken Biriyani', 'Chicken biriyani is served with raita', 500.00, '46268.png', '2019-04-02 07:50:25', '2019-04-02 07:50:25'),
(34, 15, 'Chicken tandoori', 'Grilled chicken tandoori served with green salad', 600.00, '69317.jpeg', '2019-04-02 07:51:37', '2019-04-02 07:51:37'),
(35, 18, 'Mutton Sekuwa', 'Smoked mutton sekuwa served with Nepali salad', 400.00, '75028.jpg', '2019-04-02 07:55:44', '2019-04-02 07:55:44'),
(36, 18, 'Mutton  set', 'Thakali mutton set', 500.00, '56335.jpg', '2019-04-02 07:58:14', '2019-04-02 07:58:14'),
(37, 18, 'Mutton chop', 'Mutton chop is a deleicious item', 400.00, '81597.jpg', '2019-04-02 08:01:28', '2019-04-03 01:24:38');

-- --------------------------------------------------------

--
-- Table structure for table `reservations`
--

CREATE TABLE `reservations` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contactno` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ArrivalDay` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ArrivalTime` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `NoPeople` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `reservations`
--

INSERT INTO `reservations` (`id`, `name`, `contactno`, `email`, `ArrivalDay`, `ArrivalTime`, `NoPeople`, `created_at`, `updated_at`) VALUES
(7, 'James Prasad', '9839282728', 'James@gmail.com', '05/16/2019', '3:20 PM', '5', '2019-05-08 02:18:12', '2019-05-08 02:18:12');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobileno` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pincode` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin` tinyint(1) DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `address`, `city`, `mobileno`, `pincode`, `email`, `password`, `admin`, `status`, `remember_token`, `created_at`, `updated_at`) VALUES
(3, 'Suraj', 'Ranipauwa', 'Pokhara', '98101757488', '101038', 'Suraj@gmail.com', '$2y$10$dUtJpSEbrBUfH3Vz0.3E6eTnVjEJPHcIUlgnvaycAAV/b2zgKuD8q', 0, 0, '0h6DhU44HgWY69mRFu2SCpXIhrNzOBOYQwK3aOnnkT4bRpXmHP1fhM72RSqw', '2019-04-10 02:39:32', '2019-05-04 05:29:58'),
(7, 'Binam', 'Chorepatan-4', 'Pokhara', '9810287891', '123456', 'Binam_425@gmail.com', '$2y$10$QmQ42uDfHWXzafew11EjtukH8vQPVxX1JYFiZ1JVC.C0SZVfkCqk.', 0, 0, 'ECUfWke4Lk2IqqtgoFaFLyGERARLOEXTAWJ1xnztFk81KZKfbTyYEGTBLZmC', '2019-04-10 07:19:17', '2019-04-23 22:43:59'),
(12, 'Jenish', 'Bhairabtole', 'Pokhara', '9810175677', '123456', 'Jenish@gmail.com', '$2y$10$QPLiYUQUY5Xu/MoKDkzOU.VCFm6RKcdBnXMK/p9F1/A8nGpSCZTXa', 0, 0, 'vBKup28qPES4QiE8WQJPktk7kYiaQGpraZCk2y8Cb0ymgrfIPCFiv7ZRRMMc', '2019-04-17 09:46:02', '2019-04-17 22:12:31'),
(13, 'Ram Gurung', 'Chipledhunga', 'Pokhara', '9876542351', '345678', 'Ram@gmail.com', '$2y$10$3QtrQj2JyJC.Z8.fGqsBAOqWMQutbW6O7.nNEVUK46My4wN7b5iOu', 0, 0, 'PHScEl4TFZkhgX5YPER4DP1AGbv8GqzOZkvrMGSA4S4B0Y9fzr4wLddslZVy', '2019-04-17 11:19:19', '2019-04-17 20:57:39'),
(16, 'Dhurba', 'Tersapati', 'Pokhara', '9827638273', '456347', 'Dhurba@chor.com', '$2y$10$IHdoTSJPOdiY.C2W0TBI9.ZynvBq8/WHsygk29x/Nw4K7fGZnenFe', 0, 0, 'XYpDoc1sQEDoeoezGKCCARRfrCcKlip5iGuor9QP37xu9SDC8cw1f2G1TvDh', '2019-04-20 07:35:47', '2019-04-20 10:08:27'),
(19, 'Sushil', 'Mahendrapool', 'Pokhara', '9810175677', '123456', 'sushil_paudel@gmail.com', '$2y$10$7/N0uMmLuhvjAfuOssxOAeeeaOoW.guuAHYnD0FlRVMyBfQBpZPd6', 0, 0, '0XZpGDpsg0ZBwseWLCGpsAeT8ad3WsbNWCokDtTKiUOhjkaqMF4kDfZ9QjhS', '2019-04-23 23:49:34', '2019-04-23 23:50:26'),
(30, 'Binam', 'Bhairabtole', 'Pokhara', '9810175677', '345678', 'Binam_425@yopmail.com', '$2y$10$FCqT5ugXOR58AYsgw98PeebDOUvUHahiLz6DFaeF5bGCrNj5N2C/6', 0, 1, 'hOR001Ej6C9ANE2dQuB8vfdC7vREhnV9eqb6lv6MbCBmH56bHqAbneAs1iVC', '2019-05-05 05:15:10', '2019-05-29 02:59:21'),
(31, 'dambr', 'fulbari', 'Pokhara', '9826192329', '123456', 'dambar@yopmail.com', '$2y$10$FTLgbOrORpdrndoo9sISLuJ/PJ.Zn9REatCOPa.fPMSWv3C8zcas.', 0, 1, 'EZlktfrVh7a2Sit5VqmhZTo4qPoXbCHbs0NtrgwkJBYg824Qojir1PpcGs6A', '2019-05-06 23:16:56', '2019-05-06 23:25:06'),
(33, 'Saramsa425', 'Ranipauwa', 'Pokhara', '9810173766', '234567', 'ssaramsa@gmail.com', '$2y$10$.4K3hXhAC5a7MsJAGR/ILOpdBnKTMDumiyJmJ.bJyoB4.m8LE0SHu', 0, 1, 'zC4kGNh4lbPLVAnlRI3TWTpvtFIGEie6y8wHKJT5ziawtokUpeJj7GZKW4zv', '2019-05-08 04:49:09', '2019-05-29 23:33:57'),
(34, 'Admin', '', '', '', '', 'admin@gmail.com', '$2y$10$DVUzS/uob3mFn44Hwo0v3uHryDc53AchkWLTGklKSQXPQdEZcTaTy', 0, 0, '6E6Y4Lan7nn8UUiSmL9bjBPEEzKh8lHDq0MQ6dDmppQSIkJRdTIX5l0BYDNq', '2019-05-10 01:04:50', '2019-05-10 01:04:50'),
(35, 'Ram', '', '', '', '', 'Ram@yopmail.com', '$2y$10$GkpuWOtnM2mwYjoQgLpBLO3EuF5EI3fEa/9sByUoqGKj03x2JHfx.', 0, 0, 'XLGbLY0bQQPZDdVgXlCcAiRNmOdOhTgWliIudx1I9WIRtR4Igxndx01I3jEW', '2019-05-29 20:41:40', '2019-05-29 20:41:40'),
(36, 'Rabi Shrestha', '', '', '', '', 'psychrabi@gmail.com', '$2y$10$n1XKDbstDKq02Hr1rfU.hOoPtb/KAwKFJAq6tD5FSFepP5ZewLLoO', 0, 0, NULL, '2019-10-20 00:32:20', '2019-10-20 00:32:20');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `carts`
--
ALTER TABLE `carts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `delievery_addresses`
--
ALTER TABLE `delievery_addresses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `foods`
--
ALTER TABLE `foods`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_products`
--
ALTER TABLE `order_products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reservations`
--
ALTER TABLE `reservations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `carts`
--
ALTER TABLE `carts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT for table `contacts`
--
ALTER TABLE `contacts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `delievery_addresses`
--
ALTER TABLE `delievery_addresses`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `foods`
--
ALTER TABLE `foods`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `order_products`
--
ALTER TABLE `order_products`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;
--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;
--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;
--
-- AUTO_INCREMENT for table `reservations`
--
ALTER TABLE `reservations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;--
-- Database: `multiauthsystem`
--
CREATE DATABASE IF NOT EXISTS `multiauthsystem` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `multiauthsystem`;

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(10, '2014_10_12_000000_create_users_table', 1),
(11, '2014_10_12_100000_create_password_resets_table', 1),
(12, '2019_09_21_041717_create_admin_table', 1),
(13, '2019_09_24_115105_create_posts_table', 1),
(14, '2019_09_24_163914_add_slug_posts', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `body` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `title`, `body`, `slug`, `created_at`, `updated_at`) VALUES
(1, 'Post one', 'His break dome caught unto forgot, could in loved heart yet departed deemed day most than, loved pollution harold start shun mothernot, strength one ever birth who would some fathers.', 'first-post', '2019-09-25 07:56:40', '2019-09-25 07:56:40'),
(3, 'Post two', 'Piú sé potra volta e dinanzi fatica che. Nostra alla senza i cosí fatica pieno di piene da, divenuti sí purita in e, l\'acume da furono sempre novella.', 'second-post', '2019-09-25 08:18:05', '2019-09-25 08:18:05');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastname` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `lastname`, `email`, `image`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Anish', 'magar', 'Anish@gmail.com', 'acb295e52e549a7739557774ca8b07e5c0908de3.png', '$2y$10$NjvO0sTvzR4K7Mk0aBpgfuYZN4QBTzgVRW2szMagIMF7P5Uy0nhtG', 'b3pkvTkKBAnHdr5St8GmIaOXbWrYmoz2ZnKvaW5XLHAmUf3tuoLeAjtzkC2L', '2019-09-26 03:13:53', '2019-09-26 03:13:53');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `admins_email_unique` (`email`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `posts_slug_unique` (`slug`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;--
-- Database: `myflaskapp`
--
CREATE DATABASE IF NOT EXISTS `myflaskapp` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `myflaskapp`;

-- --------------------------------------------------------

--
-- Table structure for table `articles`
--

CREATE TABLE `articles` (
  `iD` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `author` varchar(100) DEFAULT NULL,
  `body` text,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `username` varchar(30) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `registered_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `username`, `password`, `registered_date`) VALUES
(1, 'saramsa', 'Suraj@gmail.com', 'Sar425', '$5$rounds=535000$sgl9I3WYWx3C3rXG$s4HC6lcK/Ba/VoVqGjPONhMH2orFLsAZ81hKoFo87D8', '2019-08-21 08:46:51'),
(2, 'Jenish', 'Jenish@gmail.com', 'Jenish123', '$5$rounds=535000$CxnhWLM3RZzAEm3d$06AHqrgYolkVLY10.l8i7BVrXGfb60ilEWeZfzsOJjD', '2019-08-21 08:48:57');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `articles`
--
ALTER TABLE `articles`
  ADD PRIMARY KEY (`iD`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `articles`
--
ALTER TABLE `articles`
  MODIFY `iD` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;--
-- Database: `offiece`
--
CREATE DATABASE IF NOT EXISTS `offiece` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `offiece`;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(141) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'saramsa', 'sherchan_hari@live.com', '$2y$10$COBsTQMn1DvFsjp4LhMSFuJ0VdehE2C6kZNdqEGn1rdrq7Q9y3r7.', 'YNHDXadKpvTW815RIuSjGx5n8ZFAbPR8ZJAnSG0WpRRQti0n5OzK0oRcnkYG', '2019-01-09 02:24:26', '2019-01-09 02:24:26');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;--
-- Database: `phpmyadmin`
--
CREATE DATABASE IF NOT EXISTS `phpmyadmin` DEFAULT CHARACTER SET utf8 COLLATE utf8_bin;
USE `phpmyadmin`;

-- --------------------------------------------------------

--
-- Table structure for table `pma__bookmark`
--

CREATE TABLE `pma__bookmark` (
  `id` int(11) NOT NULL,
  `dbase` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `user` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `label` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `query` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Bookmarks';

-- --------------------------------------------------------

--
-- Table structure for table `pma__central_columns`
--

CREATE TABLE `pma__central_columns` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `col_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `col_type` varchar(64) COLLATE utf8_bin NOT NULL,
  `col_length` text COLLATE utf8_bin,
  `col_collation` varchar(64) COLLATE utf8_bin NOT NULL,
  `col_isNull` tinyint(1) NOT NULL,
  `col_extra` varchar(255) COLLATE utf8_bin DEFAULT '',
  `col_default` text COLLATE utf8_bin
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Central list of columns';

-- --------------------------------------------------------

--
-- Table structure for table `pma__column_info`
--

CREATE TABLE `pma__column_info` (
  `id` int(5) UNSIGNED NOT NULL,
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `column_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `comment` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `mimetype` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `transformation` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `transformation_options` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `input_transformation` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `input_transformation_options` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Column information for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__designer_settings`
--

CREATE TABLE `pma__designer_settings` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `settings_data` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Settings related to Designer';

--
-- Dumping data for table `pma__designer_settings`
--

INSERT INTO `pma__designer_settings` (`username`, `settings_data`) VALUES
('root', '{\"angular_direct\":\"direct\",\"snap_to_grid\":\"off\",\"relation_lines\":\"true\",\"full_screen\":\"on\"}');

-- --------------------------------------------------------

--
-- Table structure for table `pma__export_templates`
--

CREATE TABLE `pma__export_templates` (
  `id` int(5) UNSIGNED NOT NULL,
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `export_type` varchar(10) COLLATE utf8_bin NOT NULL,
  `template_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `template_data` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Saved export templates';

--
-- Dumping data for table `pma__export_templates`
--

INSERT INTO `pma__export_templates` (`id`, `username`, `export_type`, `template_name`, `template_data`) VALUES
(1, 'root', 'database', 'bethesda', '{\"quick_or_custom\":\"quick\",\"what\":\"sql\",\"structure_or_data_forced\":\"0\",\"table_select[]\":[\"downloads\",\"feedback\",\"galleries\",\"members\",\"migrations\",\"news\",\"notices\",\"notics\",\"pages\",\"password_resets\",\"photos\",\"projects\",\"reports\",\"sliders\",\"teams\",\"users\"],\"table_structure[]\":[\"downloads\",\"feedback\",\"galleries\",\"members\",\"migrations\",\"news\",\"notices\",\"notics\",\"pages\",\"password_resets\",\"photos\",\"projects\",\"reports\",\"sliders\",\"teams\",\"users\"],\"table_data[]\":[\"downloads\",\"feedback\",\"galleries\",\"members\",\"migrations\",\"news\",\"notices\",\"notics\",\"pages\",\"password_resets\",\"photos\",\"projects\",\"reports\",\"sliders\",\"teams\",\"users\"],\"output_format\":\"sendit\",\"filename_template\":\"@DATABASE@\",\"remember_template\":\"on\",\"charset\":\"utf-8\",\"compression\":\"none\",\"maxsize\":\"\",\"codegen_structure_or_data\":\"data\",\"codegen_format\":\"0\",\"csv_separator\":\",\",\"csv_enclosed\":\"\\\"\",\"csv_escaped\":\"\\\"\",\"csv_terminated\":\"AUTO\",\"csv_null\":\"NULL\",\"csv_structure_or_data\":\"data\",\"excel_null\":\"NULL\",\"excel_edition\":\"win\",\"excel_structure_or_data\":\"data\",\"htmlword_structure_or_data\":\"structure_and_data\",\"htmlword_null\":\"NULL\",\"json_structure_or_data\":\"data\",\"latex_caption\":\"something\",\"latex_structure_or_data\":\"structure_and_data\",\"latex_structure_caption\":\"Structure of table @TABLE@\",\"latex_structure_continued_caption\":\"Structure of table @TABLE@ (continued)\",\"latex_structure_label\":\"tab:@TABLE@-structure\",\"latex_relation\":\"something\",\"latex_comments\":\"something\",\"latex_mime\":\"something\",\"latex_columns\":\"something\",\"latex_data_caption\":\"Content of table @TABLE@\",\"latex_data_continued_caption\":\"Content of table @TABLE@ (continued)\",\"latex_data_label\":\"tab:@TABLE@-data\",\"latex_null\":\"\\\\textit{NULL}\",\"mediawiki_structure_or_data\":\"structure_and_data\",\"mediawiki_caption\":\"something\",\"mediawiki_headers\":\"something\",\"ods_null\":\"NULL\",\"ods_structure_or_data\":\"data\",\"odt_structure_or_data\":\"structure_and_data\",\"odt_relation\":\"something\",\"odt_comments\":\"something\",\"odt_mime\":\"something\",\"odt_columns\":\"something\",\"odt_null\":\"NULL\",\"pdf_report_title\":\"\",\"pdf_structure_or_data\":\"structure_and_data\",\"phparray_structure_or_data\":\"data\",\"sql_include_comments\":\"something\",\"sql_header_comment\":\"\",\"sql_compatibility\":\"NONE\",\"sql_structure_or_data\":\"structure_and_data\",\"sql_create_table\":\"something\",\"sql_auto_increment\":\"something\",\"sql_create_view\":\"something\",\"sql_procedure_function\":\"something\",\"sql_create_trigger\":\"something\",\"sql_backquotes\":\"something\",\"sql_type\":\"INSERT\",\"sql_insert_syntax\":\"both\",\"sql_max_query_size\":\"50000\",\"sql_hex_for_binary\":\"something\",\"sql_utc_time\":\"something\",\"texytext_structure_or_data\":\"structure_and_data\",\"texytext_null\":\"NULL\",\"xml_structure_or_data\":\"data\",\"xml_export_events\":\"something\",\"xml_export_functions\":\"something\",\"xml_export_procedures\":\"something\",\"xml_export_tables\":\"something\",\"xml_export_triggers\":\"something\",\"xml_export_views\":\"something\",\"xml_export_contents\":\"something\",\"yaml_structure_or_data\":\"data\",\"\":null,\"lock_tables\":null,\"as_separate_files\":null,\"csv_removeCRLF\":null,\"csv_columns\":null,\"excel_removeCRLF\":null,\"excel_columns\":null,\"htmlword_columns\":null,\"json_pretty_print\":null,\"ods_columns\":null,\"sql_dates\":null,\"sql_relation\":null,\"sql_mime\":null,\"sql_use_transaction\":null,\"sql_disable_fk\":null,\"sql_views_as_tables\":null,\"sql_metadata\":null,\"sql_create_database\":null,\"sql_drop_table\":null,\"sql_if_not_exists\":null,\"sql_truncate\":null,\"sql_delayed\":null,\"sql_ignore\":null,\"texytext_columns\":null}'),
(2, 'root', 'database', 'FYP', '{\"quick_or_custom\":\"quick\",\"what\":\"sql\",\"structure_or_data_forced\":\"0\",\"table_select[]\":[\"carts\",\"categories\",\"contacts\",\"foods\",\"migrations\",\"password_resets\",\"products\",\"reservations\",\"users\"],\"table_structure[]\":[\"carts\",\"categories\",\"contacts\",\"foods\",\"migrations\",\"password_resets\",\"products\",\"reservations\",\"users\"],\"table_data[]\":[\"carts\",\"categories\",\"contacts\",\"foods\",\"migrations\",\"password_resets\",\"products\",\"reservations\",\"users\"],\"output_format\":\"sendit\",\"filename_template\":\"@DATABASE@\",\"remember_template\":\"on\",\"charset\":\"utf-8\",\"compression\":\"none\",\"maxsize\":\"\",\"codegen_structure_or_data\":\"data\",\"codegen_format\":\"0\",\"csv_separator\":\",\",\"csv_enclosed\":\"\\\"\",\"csv_escaped\":\"\\\"\",\"csv_terminated\":\"AUTO\",\"csv_null\":\"NULL\",\"csv_structure_or_data\":\"data\",\"excel_null\":\"NULL\",\"excel_edition\":\"win\",\"excel_structure_or_data\":\"data\",\"htmlword_structure_or_data\":\"structure_and_data\",\"htmlword_null\":\"NULL\",\"json_structure_or_data\":\"data\",\"latex_caption\":\"something\",\"latex_structure_or_data\":\"structure_and_data\",\"latex_structure_caption\":\"Structure of table @TABLE@\",\"latex_structure_continued_caption\":\"Structure of table @TABLE@ (continued)\",\"latex_structure_label\":\"tab:@TABLE@-structure\",\"latex_relation\":\"something\",\"latex_comments\":\"something\",\"latex_mime\":\"something\",\"latex_columns\":\"something\",\"latex_data_caption\":\"Content of table @TABLE@\",\"latex_data_continued_caption\":\"Content of table @TABLE@ (continued)\",\"latex_data_label\":\"tab:@TABLE@-data\",\"latex_null\":\"\\\\textit{NULL}\",\"mediawiki_structure_or_data\":\"structure_and_data\",\"mediawiki_caption\":\"something\",\"mediawiki_headers\":\"something\",\"ods_null\":\"NULL\",\"ods_structure_or_data\":\"data\",\"odt_structure_or_data\":\"structure_and_data\",\"odt_relation\":\"something\",\"odt_comments\":\"something\",\"odt_mime\":\"something\",\"odt_columns\":\"something\",\"odt_null\":\"NULL\",\"pdf_report_title\":\"\",\"pdf_structure_or_data\":\"structure_and_data\",\"phparray_structure_or_data\":\"data\",\"sql_include_comments\":\"something\",\"sql_header_comment\":\"\",\"sql_compatibility\":\"NONE\",\"sql_structure_or_data\":\"structure_and_data\",\"sql_create_table\":\"something\",\"sql_auto_increment\":\"something\",\"sql_create_view\":\"something\",\"sql_procedure_function\":\"something\",\"sql_create_trigger\":\"something\",\"sql_backquotes\":\"something\",\"sql_type\":\"INSERT\",\"sql_insert_syntax\":\"both\",\"sql_max_query_size\":\"50000\",\"sql_hex_for_binary\":\"something\",\"sql_utc_time\":\"something\",\"texytext_structure_or_data\":\"structure_and_data\",\"texytext_null\":\"NULL\",\"xml_structure_or_data\":\"data\",\"xml_export_events\":\"something\",\"xml_export_functions\":\"something\",\"xml_export_procedures\":\"something\",\"xml_export_tables\":\"something\",\"xml_export_triggers\":\"something\",\"xml_export_views\":\"something\",\"xml_export_contents\":\"something\",\"yaml_structure_or_data\":\"data\",\"\":null,\"lock_tables\":null,\"as_separate_files\":null,\"csv_removeCRLF\":null,\"csv_columns\":null,\"excel_removeCRLF\":null,\"excel_columns\":null,\"htmlword_columns\":null,\"json_pretty_print\":null,\"ods_columns\":null,\"sql_dates\":null,\"sql_relation\":null,\"sql_mime\":null,\"sql_use_transaction\":null,\"sql_disable_fk\":null,\"sql_views_as_tables\":null,\"sql_metadata\":null,\"sql_create_database\":null,\"sql_drop_table\":null,\"sql_if_not_exists\":null,\"sql_truncate\":null,\"sql_delayed\":null,\"sql_ignore\":null,\"texytext_columns\":null}'),
(3, 'root', 'database', 'MantraThakali', '{\"quick_or_custom\":\"quick\",\"what\":\"sql\",\"structure_or_data_forced\":\"0\",\"table_select[]\":[\"admins\",\"carts\",\"categories\",\"contacts\",\"delievery_addresses\",\"foods\",\"migrations\",\"orders\",\"order_products\",\"password_resets\",\"products\",\"reservations\",\"users\"],\"table_structure[]\":[\"admins\",\"carts\",\"categories\",\"contacts\",\"delievery_addresses\",\"foods\",\"migrations\",\"orders\",\"order_products\",\"password_resets\",\"products\",\"reservations\",\"users\"],\"table_data[]\":[\"admins\",\"carts\",\"categories\",\"contacts\",\"delievery_addresses\",\"foods\",\"migrations\",\"orders\",\"order_products\",\"password_resets\",\"products\",\"reservations\",\"users\"],\"output_format\":\"sendit\",\"filename_template\":\"@DATABASE@\",\"remember_template\":\"on\",\"charset\":\"utf-8\",\"compression\":\"none\",\"maxsize\":\"\",\"codegen_structure_or_data\":\"data\",\"codegen_format\":\"0\",\"csv_separator\":\",\",\"csv_enclosed\":\"\\\"\",\"csv_escaped\":\"\\\"\",\"csv_terminated\":\"AUTO\",\"csv_null\":\"NULL\",\"csv_structure_or_data\":\"data\",\"excel_null\":\"NULL\",\"excel_edition\":\"win\",\"excel_structure_or_data\":\"data\",\"htmlword_structure_or_data\":\"structure_and_data\",\"htmlword_null\":\"NULL\",\"json_structure_or_data\":\"data\",\"latex_caption\":\"something\",\"latex_structure_or_data\":\"structure_and_data\",\"latex_structure_caption\":\"Structure of table @TABLE@\",\"latex_structure_continued_caption\":\"Structure of table @TABLE@ (continued)\",\"latex_structure_label\":\"tab:@TABLE@-structure\",\"latex_relation\":\"something\",\"latex_comments\":\"something\",\"latex_mime\":\"something\",\"latex_columns\":\"something\",\"latex_data_caption\":\"Content of table @TABLE@\",\"latex_data_continued_caption\":\"Content of table @TABLE@ (continued)\",\"latex_data_label\":\"tab:@TABLE@-data\",\"latex_null\":\"\\\\textit{NULL}\",\"mediawiki_structure_or_data\":\"structure_and_data\",\"mediawiki_caption\":\"something\",\"mediawiki_headers\":\"something\",\"ods_null\":\"NULL\",\"ods_structure_or_data\":\"data\",\"odt_structure_or_data\":\"structure_and_data\",\"odt_relation\":\"something\",\"odt_comments\":\"something\",\"odt_mime\":\"something\",\"odt_columns\":\"something\",\"odt_null\":\"NULL\",\"pdf_report_title\":\"\",\"pdf_structure_or_data\":\"structure_and_data\",\"phparray_structure_or_data\":\"data\",\"sql_include_comments\":\"something\",\"sql_header_comment\":\"\",\"sql_compatibility\":\"NONE\",\"sql_structure_or_data\":\"structure_and_data\",\"sql_create_table\":\"something\",\"sql_auto_increment\":\"something\",\"sql_create_view\":\"something\",\"sql_procedure_function\":\"something\",\"sql_create_trigger\":\"something\",\"sql_backquotes\":\"something\",\"sql_type\":\"INSERT\",\"sql_insert_syntax\":\"both\",\"sql_max_query_size\":\"50000\",\"sql_hex_for_binary\":\"something\",\"sql_utc_time\":\"something\",\"texytext_structure_or_data\":\"structure_and_data\",\"texytext_null\":\"NULL\",\"xml_structure_or_data\":\"data\",\"xml_export_events\":\"something\",\"xml_export_functions\":\"something\",\"xml_export_procedures\":\"something\",\"xml_export_tables\":\"something\",\"xml_export_triggers\":\"something\",\"xml_export_views\":\"something\",\"xml_export_contents\":\"something\",\"yaml_structure_or_data\":\"data\",\"\":null,\"lock_tables\":null,\"as_separate_files\":null,\"csv_removeCRLF\":null,\"csv_columns\":null,\"excel_removeCRLF\":null,\"excel_columns\":null,\"htmlword_columns\":null,\"json_pretty_print\":null,\"ods_columns\":null,\"sql_dates\":null,\"sql_relation\":null,\"sql_mime\":null,\"sql_use_transaction\":null,\"sql_disable_fk\":null,\"sql_views_as_tables\":null,\"sql_metadata\":null,\"sql_create_database\":null,\"sql_drop_table\":null,\"sql_if_not_exists\":null,\"sql_truncate\":null,\"sql_delayed\":null,\"sql_ignore\":null,\"texytext_columns\":null}'),
(4, 'root', 'database', 'Final year project database', '{\"quick_or_custom\":\"quick\",\"what\":\"sql\",\"structure_or_data_forced\":\"0\",\"table_select[]\":[\"admins\",\"carts\",\"categories\",\"contacts\",\"delievery_addresses\",\"foods\",\"migrations\",\"orders\",\"order_products\",\"password_resets\",\"products\",\"reservations\",\"users\"],\"table_structure[]\":[\"admins\",\"carts\",\"categories\",\"contacts\",\"delievery_addresses\",\"foods\",\"migrations\",\"orders\",\"order_products\",\"password_resets\",\"products\",\"reservations\",\"users\"],\"table_data[]\":[\"admins\",\"carts\",\"categories\",\"contacts\",\"delievery_addresses\",\"foods\",\"migrations\",\"orders\",\"order_products\",\"password_resets\",\"products\",\"reservations\",\"users\"],\"output_format\":\"sendit\",\"filename_template\":\"@DATABASE@\",\"remember_template\":\"on\",\"charset\":\"utf-8\",\"compression\":\"none\",\"maxsize\":\"\",\"codegen_structure_or_data\":\"data\",\"codegen_format\":\"0\",\"csv_separator\":\",\",\"csv_enclosed\":\"\\\"\",\"csv_escaped\":\"\\\"\",\"csv_terminated\":\"AUTO\",\"csv_null\":\"NULL\",\"csv_structure_or_data\":\"data\",\"excel_null\":\"NULL\",\"excel_edition\":\"win\",\"excel_structure_or_data\":\"data\",\"htmlword_structure_or_data\":\"structure_and_data\",\"htmlword_null\":\"NULL\",\"json_structure_or_data\":\"data\",\"latex_caption\":\"something\",\"latex_structure_or_data\":\"structure_and_data\",\"latex_structure_caption\":\"Structure of table @TABLE@\",\"latex_structure_continued_caption\":\"Structure of table @TABLE@ (continued)\",\"latex_structure_label\":\"tab:@TABLE@-structure\",\"latex_relation\":\"something\",\"latex_comments\":\"something\",\"latex_mime\":\"something\",\"latex_columns\":\"something\",\"latex_data_caption\":\"Content of table @TABLE@\",\"latex_data_continued_caption\":\"Content of table @TABLE@ (continued)\",\"latex_data_label\":\"tab:@TABLE@-data\",\"latex_null\":\"\\\\textit{NULL}\",\"mediawiki_structure_or_data\":\"structure_and_data\",\"mediawiki_caption\":\"something\",\"mediawiki_headers\":\"something\",\"ods_null\":\"NULL\",\"ods_structure_or_data\":\"data\",\"odt_structure_or_data\":\"structure_and_data\",\"odt_relation\":\"something\",\"odt_comments\":\"something\",\"odt_mime\":\"something\",\"odt_columns\":\"something\",\"odt_null\":\"NULL\",\"pdf_report_title\":\"\",\"pdf_structure_or_data\":\"structure_and_data\",\"phparray_structure_or_data\":\"data\",\"sql_include_comments\":\"something\",\"sql_header_comment\":\"\",\"sql_compatibility\":\"NONE\",\"sql_structure_or_data\":\"structure_and_data\",\"sql_create_table\":\"something\",\"sql_auto_increment\":\"something\",\"sql_create_view\":\"something\",\"sql_procedure_function\":\"something\",\"sql_create_trigger\":\"something\",\"sql_backquotes\":\"something\",\"sql_type\":\"INSERT\",\"sql_insert_syntax\":\"both\",\"sql_max_query_size\":\"50000\",\"sql_hex_for_binary\":\"something\",\"sql_utc_time\":\"something\",\"texytext_structure_or_data\":\"structure_and_data\",\"texytext_null\":\"NULL\",\"xml_structure_or_data\":\"data\",\"xml_export_events\":\"something\",\"xml_export_functions\":\"something\",\"xml_export_procedures\":\"something\",\"xml_export_tables\":\"something\",\"xml_export_triggers\":\"something\",\"xml_export_views\":\"something\",\"xml_export_contents\":\"something\",\"yaml_structure_or_data\":\"data\",\"\":null,\"lock_tables\":null,\"as_separate_files\":null,\"csv_removeCRLF\":null,\"csv_columns\":null,\"excel_removeCRLF\":null,\"excel_columns\":null,\"htmlword_columns\":null,\"json_pretty_print\":null,\"ods_columns\":null,\"sql_dates\":null,\"sql_relation\":null,\"sql_mime\":null,\"sql_use_transaction\":null,\"sql_disable_fk\":null,\"sql_views_as_tables\":null,\"sql_metadata\":null,\"sql_create_database\":null,\"sql_drop_table\":null,\"sql_if_not_exists\":null,\"sql_truncate\":null,\"sql_delayed\":null,\"sql_ignore\":null,\"texytext_columns\":null}');

-- --------------------------------------------------------

--
-- Table structure for table `pma__favorite`
--

CREATE TABLE `pma__favorite` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `tables` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Favorite tables';

-- --------------------------------------------------------

--
-- Table structure for table `pma__history`
--

CREATE TABLE `pma__history` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `username` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `db` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `timevalue` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `sqlquery` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='SQL history for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__navigationhiding`
--

CREATE TABLE `pma__navigationhiding` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `item_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `item_type` varchar(64) COLLATE utf8_bin NOT NULL,
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Hidden items of navigation tree';

-- --------------------------------------------------------

--
-- Table structure for table `pma__pdf_pages`
--

CREATE TABLE `pma__pdf_pages` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `page_nr` int(10) UNSIGNED NOT NULL,
  `page_descr` varchar(50) CHARACTER SET utf8 NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='PDF relation pages for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__recent`
--

CREATE TABLE `pma__recent` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `tables` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Recently accessed tables';

--
-- Dumping data for table `pma__recent`
--

INSERT INTO `pma__recent` (`username`, `tables`) VALUES
('root', '[{\"db\":\"inventory\",\"table\":\"stocks\"},{\"db\":\"inventory\",\"table\":\"stock__purchaseds\"},{\"db\":\"inventory\",\"table\":\"stock_availables\"},{\"db\":\"inventory\",\"table\":\"customers\"},{\"db\":\"inventory\",\"table\":\"products\"},{\"db\":\"inventory\",\"table\":\"suppliers\"},{\"db\":\"inventory\",\"table\":\"categories\"},{\"db\":\"inventory\",\"table\":\"admins\"},{\"db\":\"blogsimple\",\"table\":\"users\"},{\"db\":\"blogsimple\",\"table\":\"tags\"}]');

-- --------------------------------------------------------

--
-- Table structure for table `pma__relation`
--

CREATE TABLE `pma__relation` (
  `master_db` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `master_table` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `master_field` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `foreign_db` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `foreign_table` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `foreign_field` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Relation table';

-- --------------------------------------------------------

--
-- Table structure for table `pma__savedsearches`
--

CREATE TABLE `pma__savedsearches` (
  `id` int(5) UNSIGNED NOT NULL,
  `username` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `search_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `search_data` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Saved searches';

-- --------------------------------------------------------

--
-- Table structure for table `pma__table_coords`
--

CREATE TABLE `pma__table_coords` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `pdf_page_number` int(11) NOT NULL DEFAULT '0',
  `x` float UNSIGNED NOT NULL DEFAULT '0',
  `y` float UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Table coordinates for phpMyAdmin PDF output';

-- --------------------------------------------------------

--
-- Table structure for table `pma__table_info`
--

CREATE TABLE `pma__table_info` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `display_field` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Table information for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__table_uiprefs`
--

CREATE TABLE `pma__table_uiprefs` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `prefs` text COLLATE utf8_bin NOT NULL,
  `last_update` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Tables'' UI preferences';

--
-- Dumping data for table `pma__table_uiprefs`
--

INSERT INTO `pma__table_uiprefs` (`username`, `db_name`, `table_name`, `prefs`, `last_update`) VALUES
('root', 'inventory', 'products', '{\"sorted_col\":\"`products`.`product_desc` ASC\"}', '2019-11-09 16:20:03'),
('root', 'mantra_thakola', 'users', '[]', '2019-04-12 10:43:35');

-- --------------------------------------------------------

--
-- Table structure for table `pma__tracking`
--

CREATE TABLE `pma__tracking` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `version` int(10) UNSIGNED NOT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` datetime NOT NULL,
  `schema_snapshot` text COLLATE utf8_bin NOT NULL,
  `schema_sql` text COLLATE utf8_bin,
  `data_sql` longtext COLLATE utf8_bin,
  `tracking` set('UPDATE','REPLACE','INSERT','DELETE','TRUNCATE','CREATE DATABASE','ALTER DATABASE','DROP DATABASE','CREATE TABLE','ALTER TABLE','RENAME TABLE','DROP TABLE','CREATE INDEX','DROP INDEX','CREATE VIEW','ALTER VIEW','DROP VIEW') COLLATE utf8_bin DEFAULT NULL,
  `tracking_active` int(1) UNSIGNED NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Database changes tracking for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__userconfig`
--

CREATE TABLE `pma__userconfig` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `timevalue` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `config_data` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='User preferences storage for phpMyAdmin';

--
-- Dumping data for table `pma__userconfig`
--

INSERT INTO `pma__userconfig` (`username`, `timevalue`, `config_data`) VALUES
('root', '2019-10-15 09:04:59', '{\"collation_connection\":\"utf8mb4_unicode_ci\",\"SendErrorReports\":\"always\"}');

-- --------------------------------------------------------

--
-- Table structure for table `pma__usergroups`
--

CREATE TABLE `pma__usergroups` (
  `usergroup` varchar(64) COLLATE utf8_bin NOT NULL,
  `tab` varchar(64) COLLATE utf8_bin NOT NULL,
  `allowed` enum('Y','N') COLLATE utf8_bin NOT NULL DEFAULT 'N'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='User groups with configured menu items';

-- --------------------------------------------------------

--
-- Table structure for table `pma__users`
--

CREATE TABLE `pma__users` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `usergroup` varchar(64) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Users and their assignments to user groups';

--
-- Indexes for dumped tables
--

--
-- Indexes for table `pma__bookmark`
--
ALTER TABLE `pma__bookmark`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pma__central_columns`
--
ALTER TABLE `pma__central_columns`
  ADD PRIMARY KEY (`db_name`,`col_name`);

--
-- Indexes for table `pma__column_info`
--
ALTER TABLE `pma__column_info`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `db_name` (`db_name`,`table_name`,`column_name`);

--
-- Indexes for table `pma__designer_settings`
--
ALTER TABLE `pma__designer_settings`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pma__export_templates`
--
ALTER TABLE `pma__export_templates`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `u_user_type_template` (`username`,`export_type`,`template_name`);

--
-- Indexes for table `pma__favorite`
--
ALTER TABLE `pma__favorite`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pma__history`
--
ALTER TABLE `pma__history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `username` (`username`,`db`,`table`,`timevalue`);

--
-- Indexes for table `pma__navigationhiding`
--
ALTER TABLE `pma__navigationhiding`
  ADD PRIMARY KEY (`username`,`item_name`,`item_type`,`db_name`,`table_name`);

--
-- Indexes for table `pma__pdf_pages`
--
ALTER TABLE `pma__pdf_pages`
  ADD PRIMARY KEY (`page_nr`),
  ADD KEY `db_name` (`db_name`);

--
-- Indexes for table `pma__recent`
--
ALTER TABLE `pma__recent`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pma__relation`
--
ALTER TABLE `pma__relation`
  ADD PRIMARY KEY (`master_db`,`master_table`,`master_field`),
  ADD KEY `foreign_field` (`foreign_db`,`foreign_table`);

--
-- Indexes for table `pma__savedsearches`
--
ALTER TABLE `pma__savedsearches`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `u_savedsearches_username_dbname` (`username`,`db_name`,`search_name`);

--
-- Indexes for table `pma__table_coords`
--
ALTER TABLE `pma__table_coords`
  ADD PRIMARY KEY (`db_name`,`table_name`,`pdf_page_number`);

--
-- Indexes for table `pma__table_info`
--
ALTER TABLE `pma__table_info`
  ADD PRIMARY KEY (`db_name`,`table_name`);

--
-- Indexes for table `pma__table_uiprefs`
--
ALTER TABLE `pma__table_uiprefs`
  ADD PRIMARY KEY (`username`,`db_name`,`table_name`);

--
-- Indexes for table `pma__tracking`
--
ALTER TABLE `pma__tracking`
  ADD PRIMARY KEY (`db_name`,`table_name`,`version`);

--
-- Indexes for table `pma__userconfig`
--
ALTER TABLE `pma__userconfig`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pma__usergroups`
--
ALTER TABLE `pma__usergroups`
  ADD PRIMARY KEY (`usergroup`,`tab`,`allowed`);

--
-- Indexes for table `pma__users`
--
ALTER TABLE `pma__users`
  ADD PRIMARY KEY (`username`,`usergroup`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `pma__bookmark`
--
ALTER TABLE `pma__bookmark`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pma__column_info`
--
ALTER TABLE `pma__column_info`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pma__export_templates`
--
ALTER TABLE `pma__export_templates`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `pma__history`
--
ALTER TABLE `pma__history`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pma__pdf_pages`
--
ALTER TABLE `pma__pdf_pages`
  MODIFY `page_nr` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pma__savedsearches`
--
ALTER TABLE `pma__savedsearches`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT;--
-- Database: `test`
--
CREATE DATABASE IF NOT EXISTS `test` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `test`;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
