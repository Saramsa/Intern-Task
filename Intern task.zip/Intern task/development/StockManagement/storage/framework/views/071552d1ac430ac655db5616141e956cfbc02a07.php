<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <h1 class="text-center display-4">Product details</h1>
                <table class="table table-dark">
                    <thead>
                        <tr>
                            <th>Product Id</th>
                            <th>Product name</th>
                            <th>Product description</th>
                            <th>Product category id</th>
                            <th>Product brand id</th>
                            <th>Product Image</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $product_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td scope="row"><?php echo e($item->id); ?></td>
                            <td><?php echo e($item->product_name); ?></td>
                            <td><?php echo e($item->product_desc); ?></td>
                            <td><?php echo e($item->category_id); ?></td>
                            <td><?php echo e($item->brand_id); ?></td>
                            <td><img src="<?php echo e(asset('images/product_images/'.$item->product_image)); ?>" width="200"></td>
                            <td><a class="btn btn-primary" href="<?php echo e(route('admin.delete.products',$item->id)); ?>" role="button">Delete</a>
                            <a class="btn btn-danger" href="<?php echo e(route('admin.edit.products',$item->id)); ?>" role="button">Edit</a></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admintemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\StockManagement\resources\views/product/viewproducts.blade.php ENDPATH**/ ?>