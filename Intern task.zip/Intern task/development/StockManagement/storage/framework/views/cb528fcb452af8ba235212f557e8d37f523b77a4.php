<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-6">
            <form action="" method="post" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <h1 class="display-4">Edit Products</h1>
                <div class="form-group">
                        <label for="">Category</label>
                          <select name="category_id">
                                  <?php $__currentLoopData = $cat_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <option value="<?php echo e($item->id); ?>"><?php echo e($item->categ_name); ?></option>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                      </div>
                      <div class="form-group">
                              <label for="">Brand</label>
                                <select name="brand_id">
                                  <?php $__currentLoopData = $brand_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <option value="<?php echo e($item->id); ?>"><?php echo e($item->brand_name); ?></option>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                      </div>
                <div class="form-group">
                  <label for="">Product name</label>
                    <input type="text" class="form-control" name="product_name" value="<?php echo e($product_details->product_name); ?>">
                </div>
                <div class="form-group">
                  <label for="">Product description</label>
                  <textarea class="form-control" name="product_desc" rows="3"><?php echo e($product_details->product_desc); ?></textarea>
                </div>
                <div class="form-group">
                  <label for="">Product price</label>
                  <input type="text" class="form-control" name="product_price" value="<?php echo e($product_details->product_price); ?>">
                </div>
                <div class="form-group">
                  <label for="">Product image</label>
                  <input type="file" class="form-control-file" name="product_image">
                    <img src="<?php echo e(asset('images/product_images/'.$product_details->product_image)); ?>" width="200">
                </div>
                <button type="submit" class="btn btn-success">Edit</button>
            </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admintemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\StockManagement\resources\views/product/editproduct.blade.php ENDPATH**/ ?>