<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <table class="table table-dark">
                    <thead>
                        <tr>
                            <th>Category id</th>
                            <th>Category name</th>
                            <th>Category description</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $cat_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                        <td scope="row"><?php echo e($item->id); ?></td>
                            <td><?php echo e($item->categ_name); ?></td>
                            <td><?php echo e($item->categ_desc); ?></td>
                        <td><a class="btn btn-danger" href="<?php echo e(route('admin.delete.categories',$item->id)); ?>" role="button">DELETE</a>
                            <a class="btn btn-primary" href="<?php echo e(route('admin.edit.categories',$item->id)); ?>" role="button">EDIT</a></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admintemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\StockManagement\resources\views/category/viewcategories.blade.php ENDPATH**/ ?>