<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <h1 class="text-center display-4">General Sales Report</h1>
        </div>
        <div class="row">
            <div class="col-md-6">
                <h1 class="display-4">Total Customer<span class="badge badge-pill badge-primary"><?php echo e($total_customer); ?></span></h1>
            </div>
            <div class="col-md-6">
                    <h1 class="display-4">Total Supplier<span class="badge badge-pill badge-danger"><?php echo e($total_supplier); ?></span></h1>
            </div>
            <div class="col-md-6">
                    <h1 class="display-4">Total available stock<span class="badge badge-pill badge-success"><?php echo e($total_stock); ?></span></h1>
            </div>
            <div class="col-md-6">
                    <h1 class="display-4">Total sales amount RS:<span class="badge badge-pill badge-warning"><?php echo e($total_sales); ?></span></h1>
            </div>
            <div class="col-md-6">
                    <h1 class="display-4">Total amount of stock broughtin:<span class="badge badge-pill badge-warning"><?php echo e($total_broughtinstock); ?></span></h1>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admintemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\StockManagement\resources\views/stock/report.blade.php ENDPATH**/ ?>