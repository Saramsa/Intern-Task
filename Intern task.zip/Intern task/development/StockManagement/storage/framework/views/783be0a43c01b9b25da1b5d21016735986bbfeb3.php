<?php $__env->startSection('content'); ?>
    <div class="jumbotron">
    <h1 class="display-3 text-center">Welcome <?php echo e($admin_details->username); ?></h1>
        <hr class="my-2">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <ul class="list-group">
                        <li class="list-group-item"><a class="btn btn-primary" href="<?php echo e(route('admin.add.stock')); ?>" role="button">Add Stock details</a></li>
                        <li class="list-group-item"><a class="btn btn-danger" href="<?php echo e(route('admin.view.stock')); ?>" role="button">Manage Stock details</a></li>
                        <li class="list-group-item"><a class="btn btn-success" href="<?php echo e(route('customer.stock.purchase')); ?>" role="button">Purchase Stock</a></li>
                        <li class="list-group-item"><a class="btn btn-primary" href="<?php echo e(route('view.stock.purchase')); ?>" role="button">Manage Purchase Stock details</a></li>
                        <li class="list-group-item"><a class="btn btn-success" href="<?php echo e(route('admin.view.avaialable-stock')); ?>" role="button">View Stock availability</a></li>
                        <li class="list-group-item"><a class="btn btn-danger" href="<?php echo e(route('admin.sales.report')); ?>" role="button">General Sales Report</a></li>
                     </ul>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admintemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\StockManagement\resources\views/admin/admindashboard.blade.php ENDPATH**/ ?>