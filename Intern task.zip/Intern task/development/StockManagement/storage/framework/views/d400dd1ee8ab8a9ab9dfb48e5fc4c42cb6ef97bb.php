<?php if(Session::has('message')): ?>
<p class="alert alert-info"><?php echo e(Session::get('message')); ?></p>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\StockManagement\resources\views/message.blade.php ENDPATH**/ ?>