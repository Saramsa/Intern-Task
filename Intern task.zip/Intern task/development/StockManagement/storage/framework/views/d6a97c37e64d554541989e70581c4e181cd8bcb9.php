<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-6">
            <h1 class="text-center display-4">EDIT SUPPLIER DETAILS</h1>
            <form action="<?php echo e(route('EditSuppliersDetails',$sup_details->id)); ?>" method="post" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <div class="form-group">
                  <label for="">Supplier name</label>
                    <input type="text" class="form-control" name="supplier_name" value="<?php echo e($sup_details->supplier_name); ?>">
                </div>
                <div class="form-group">
                  <label for="">Supplier address</label>
                  <input type="text" class="form-control" name="supplier_address" value="<?php echo e($sup_details->supplier_address); ?>">
                </div>
                <div class="form-group">
                  <label for="">Supplier contactno</label>
                  <input type="text" class="form-control" name="contactno" value="<?php echo e($sup_details->contactno); ?>">
                </div>
                <button type="submit" class="btn btn-success">EDIT</button>
            </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admintemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\StockManagement\resources\views/supplier/editsupplier.blade.php ENDPATH**/ ?>