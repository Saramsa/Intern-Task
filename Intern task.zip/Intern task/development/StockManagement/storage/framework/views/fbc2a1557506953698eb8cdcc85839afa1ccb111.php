<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <h1 class="text-center display-4">Manage Stock details</h1>
            <table class="table table-dark">
                <thead>
                    <tr>
                        <th>Stock ID</th>
                        <th>Product ID</th>
                        <th>Product Image</th>
                        <th>Supplier ID</th>
                        <th>Buying price</th>
                        <th>selling price</th>
                        <th>Quantity</th>
                        <th>Total</th>
                        <th>Payment method</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                   <?php $__currentLoopData = $stock_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <tr>
                    <td scope="row"><?php echo e($item->id); ?></td>
                        <td><?php echo e($item->product_id); ?></td>
                        <td><img src="<?php echo e(asset('images/product_images/'.$item->product_image)); ?>" width="100"></td>
                        <td><?php echo e($item->supplier_id); ?></td>
                        <td><?php echo e($item->buying_price); ?></td>
                        <td><?php echo e($item->selling_price); ?></td>
                        <td><?php echo e($item->quantity); ?></td>
                        <td><?php echo e($item->total); ?></td>
                        <td><?php echo e($item->pay_mode); ?></td>
                        <td><?php echo e($item->status); ?></td>
                        <td><a class="btn btn-primary" href="<?php echo e(route('admin.delete.stock',$item->id)); ?>" role="button">DELETE</a>
                            <a class="btn btn-danger" href="<?php echo e(route('admin.edit.stock',$item->id)); ?>" role="button">EDIT</a>
                        </td>
                    </tr>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admintemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\StockManagement\resources\views/stock/viewstock.blade.php ENDPATH**/ ?>