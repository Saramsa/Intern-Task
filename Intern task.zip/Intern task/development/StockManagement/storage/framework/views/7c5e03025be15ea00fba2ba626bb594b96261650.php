<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <h1 class="text-center display-4">Purchased Stock Details</h1>
            <table class="table table-dark">
                <thead>
                    <tr>
                        <th>Product Image</th>
                        <th>Product name</th>
                        <th>Customer name</th>
                        <th>Price</th>
                        <th>Quantity</th>
                        <th>Payment</th>
                        <th>Status</th>
                        <th>Payment method</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $stock_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td scope="row"><img src="<?php echo e(asset('images/product_images/'.$item->product_image)); ?>" width="100"></td>
                        <td><?php echo e($item->product_name); ?></td>
                        <td><?php echo e($item->customer_name); ?></td>
                        <td><?php echo e($item->price); ?></td>
                        <td><?php echo e($item->quantity); ?></td>
                        <td><?php echo e($item->payment); ?></td>
                        <td><?php echo e($item->status); ?></td>
                        <td><?php echo e($item->pay_mode); ?></td>
                        <td><a class="btn btn-success" href="<?php echo e(route('delete.stock.purchase',$item->id)); ?>" role="button">DELETE</a>
                            <a class="btn btn-primary" href="<?php echo e(route('edit.stock.purchase',$item->id)); ?>" role="button">EDIT</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admintemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\StockManagement\resources\views/stock/viewstockpurchase.blade.php ENDPATH**/ ?>