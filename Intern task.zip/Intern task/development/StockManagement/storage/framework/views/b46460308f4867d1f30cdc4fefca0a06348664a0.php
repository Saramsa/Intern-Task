<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-6">
            <form action="<?php echo e(route('EditBrands',$brand_details->id)); ?>" method="post" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <h1 class="display-4">Edit Brand</h1>
                <div class="form-group">
                  <label for="">Brand name</label>
                    <input type="text" class="form-control" name="brand_name" value="<?php echo e($brand_details->brand_name); ?>">
                </div>
                <div class="form-group">
                  <label for="">Brand description</label>
                  <textarea class="form-control" name="brand_desc" rows="3"><?php echo e($brand_details->brand_desc); ?></textarea>
                </div>
                <button type="submit" class="btn btn-danger">SAVE</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admintemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\StockManagement\resources\views/brand/editbrands.blade.php ENDPATH**/ ?>