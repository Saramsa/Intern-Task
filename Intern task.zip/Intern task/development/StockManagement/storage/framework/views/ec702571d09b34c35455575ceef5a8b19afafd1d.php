<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-6">
            <form action="<?php echo e(route('EditedCategories',$cat_details->id)); ?>" method="post" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <h1 class="display-4">Edit Categories</h1>
                <div class="form-group">
                  <label for="">Category name</label>
                <input type="text" class="form-control" name="categ_name" value="<?php echo e($cat_details->categ_name); ?>">
                </div>
                <div class="form-group">
                  <label for="">Category description</label>
                <textarea class="form-control" name="categ_desc" rows="3"><?php echo e($cat_details->categ_desc); ?></textarea>
                </div>
                <button type="submit" class="btn btn-danger">SAVE</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admintemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\StockManagement\resources\views/category/editcategories.blade.php ENDPATH**/ ?>