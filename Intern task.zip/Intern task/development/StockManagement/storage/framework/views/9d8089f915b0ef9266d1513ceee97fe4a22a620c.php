<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <table class="table table-dark">
                    <thead>
                        <tr>
                            <th>Supplier ID</th>
                            <th>Supplier Name</th>
                            <th>Supplier Address</th>
                            <th>Supplier ContactNo</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $sup_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td scope="row"><?php echo e($item->id); ?></td>
                            <td><?php echo e($item->supplier_name); ?></td>
                            <td><?php echo e($item->supplier_address); ?></td>
                            <td><?php echo e($item->contactno); ?></td>
                            <td><a class="btn btn-primary" href="<?php echo e(route('admin.delete.suppliers',$item->id)); ?>" role="button">DELETE</a>
                                <a class="btn btn-success" href="<?php echo e(route('admin.edit.suppliers',$item->id)); ?>" role="button">EDIT</a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admintemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\StockManagement\resources\views/supplier/viewsuppliers.blade.php ENDPATH**/ ?>