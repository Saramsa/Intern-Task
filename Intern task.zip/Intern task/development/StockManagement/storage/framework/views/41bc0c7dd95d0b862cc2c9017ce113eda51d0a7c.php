<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <h1 class="text-center display-4">Add Stock details</h1>
        </div>
    </div>
    <form action="<?php echo e(route('AdminAddStockDetails')); ?>" method="post" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

            <div class="row">
                    <div class="col-md-4">
                            <div class="form-group">
                                    <label for="">Product name</label>
                                    <select class="form-control" name="product_id">
                                    <option>Default</option>
                                    <?php $__currentLoopData = $product_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->product_name); ?></option>   
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-4">
                                <div class="form-group">
                                        <label for="">Supplier name</label>
                                        <select class="form-control" name="supplier_id">
                                        <option>Default</option>
                                        <?php $__currentLoopData = $supplier_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->supplier_name); ?></option>   
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                              <label for="">Available stock</label>
                            <input type="text" class="form-control" name="available_stock">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="">Buying price</label>
                                <input type="text" class="form-control" name="buying_price">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="">Selling price</label>
                                <input type="text" class="form-control" name="selling_price">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="">Qauntity</label>
                                <input type="text" class="form-control" name="quantity">
                            </div>
                        </div>
                        <div class="col-md-4">
                                <div class="form-group">
                                    <label for="">Total</label>
                                    <input type="text" class="form-control" name="total">
                                </div>
                            </div>
                            <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="">Due amount</label>
                                        <input type="text" class="form-control" name="due_amount">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="">Payment</label>
                                            <input type="text" class="form-control" name="payment">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                            <div class="form-group">
                                              <label for="">Status</label>
                                              <select class="form-control" name="status">
                                                <option>Paid</option>
                                                <option>Unpaid</option>
                                                <option>Due amount left</option>
                                              </select>
                                            </div>
                                        </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                      <label for="">Pay mode</label>
                                      <select class="form-control" name="pay_mode" id="">
                                        <option>Cash</option>
                                        <option>Cheque</option>
                                      </select>
                                    </div>
                                </div>       
            </div>
            <button type="submit" class="btn btn-success">INSERT</button>      
            <button type="reset" class="btn btn-danger">Cancel</button>
        </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admintemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\StockManagement\resources\views/stock/addstock.blade.php ENDPATH**/ ?>