<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <h1 class="text-center display-4">Available Stock details</h1>
            <table class="table table-dark">
                <thead>
                    <tr>
                        <th>Product Image</th>
                        <th>Product Name</th>
                        <th>Product ID</th>
                        <th>Buying price</th>
                        <th>Selling price</th>
                        <th>Available Stock Quantity</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $stock_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                    <td scope="row"><img src="<?php echo e(asset('images/product_images/'.$item->product_image)); ?>" width="100"></td>
                        <td><?php echo e($item->product_name); ?></td>
                        <td><?php echo e($item->product_id); ?></td>
                        <td><?php echo e($item->buying_price); ?></td>
                        <td><?php echo e($item->selling_price); ?></td>
                        <td><?php echo e($item->stock_quantity); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admintemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\StockManagement\resources\views/stock/availablestock.blade.php ENDPATH**/ ?>