<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-6">
            <form action="<?php echo e(route('AdminAddCustomerDetails')); ?>" method="post" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <div class="form-group">
                  <label for="">Customer name</label>
                  <input type="text" class="form-control" name="customer_name">
                </div>
                <div class="form-group">
                  <label for="">Customer address</label>
                  <input type="text" class="form-control" name="customer_address">
                </div>
                <div class="form-group">
                  <label for="">Customer contactno</label>
                  <input type="text" class="form-control" name="contactno">
                </div>
                <button type="submit" class="btn btn-success">INSERT</button>
            </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admintemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\StockManagement\resources\views/customer/addcustomer.blade.php ENDPATH**/ ?>