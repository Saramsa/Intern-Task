<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });


Route::prefix('admin')->group(function(){

    Route::get('/login','AdminLoginController@AdminviewLogin')->name('admin.login');

    Route::post('/login','AdminLoginController@AdminLogin')->name('AdminLogin');

    Route::get('/','AdminDashboardController@AdminDashboard')->name('admin.home');

    Route::get('/logout','AdminLoginController@AdminLogout')->name('admin.logout');
    
    Route::get('/add-categories','CategoryController@AdminAddCategories')->name('admin.add.categories');

    Route::post('/add-categories','CategoryController@AddedCategories')->name('AddedCategories');

    Route::get('/view-categories','CategoryController@AdminViewCategories')->name('admin.view.categories');

    Route::get('/delete-categories/{id}','CategoryController@AdminDeleteCategories')->name('admin.delete.categories');

    Route::get('/edit-categories/{id}','CategoryController@AdminEditCategories')->name('admin.edit.categories');

    Route::post('/edit-categories/{id}','CategoryController@EditedCategories')->name('EditedCategories');

    //Brand section

    Route::get('/add-brands','AdminDashboardController@AdminAddBrands')->name('admin.add.brands');

    Route::post('/add-brands','AdminDashboardController@AddBrands')->name('AddBrands');

    Route::get('/view-brands','AdminDashboardController@AdminViewBrands')->name('admin.view.brands');

    Route::get('/delete-brands/{id}','AdminDashboardController@AdminDeleteBrands')->name('admin.delete.brands');

    Route::get('/edit-brands/{id}','AdminDashboardController@AdminEditBrands')->name('admin.edit.brands');

    Route::post('/edit-brands/{id}','AdminDashboardController@EditBrands')->name('EditBrands');

    //Product Section
    Route::get('/add-products','ProductController@AdminAddProducts')->name('admin.add.products');

    Route::post('/add-products','ProductController@AddProducts')->name('AddProducts');

    Route::get('/view-products','ProductController@ViewProducts')->name('admin.view.products');

    Route::get('/delete-products/{id}','ProductController@DeleteProducts')->name('admin.delete.products');

    Route::get('/edit-products/{id}','ProductController@EditProducts')->name('admin.edit.products');

    Route::post('/edit-products/{id}','ProductController@AdminEditProducts')->name('AdminEditProducts');

    //Supplier section
    Route::get('/add-suppliers','ProductController@AddSuppliers')->name('admin.add.suppliers');

    Route::post('/add-suppliers','ProductController@AdminAddSuppliers')->name('AdminAddSuppliers');

    Route::get('/view-suppliers','ProductController@AdminViewSuppliers')->name('admin.view.suppliers');

    Route::get('/delete-suppliers/{id}','ProductController@AdminDeleteSuppliers')->name('admin.delete.suppliers');

    Route::get('/edit-suppliers/{id}','ProductController@AdminEditSuppliers')->name('admin.edit.suppliers');

    Route::post('/edit-suppliers/{id}','ProductController@EditSuppliersDetails')->name('EditSuppliersDetails');

    //Stock section
    Route::get('/add-stock-details','StockController@AddStockDetails')->name('admin.add.stock');

    Route::post('/add-stock-details','StockController@AdminAddStockDetails')->name('AdminAddStockDetails');

    Route::get('/view-stock-details','StockController@ViewStockDetails')->name('admin.view.stock');

    Route::get('/delete-stock-details/{id}','StockController@DeleteStockDetails')->name('admin.delete.stock');

    Route::get('/edit-stock-details/{id}','StockController@EditStockDetails')->name('admin.edit.stock');

    Route::post('/edit-stock-details/{id}','StockController@AdminEditStockDetails')->name('AdminEditStockDetails');

    //Customer section

    Route::get('/add-customer-details','CustomerController@AddCustomerDetails')->name('admin.add.customer');

    Route::post('/add-customer-details','CustomerController@AdminAddCustomerDetails')->name('AdminAddCustomerDetails');

    Route::get('/view-customer-details','CustomerController@ViewCustomerDetails')->name('admin.view.customer');

    Route::get('/delete-customer-details/{id}','CustomerController@DeleteCustomerDetails')->name('admin.delete.customer');

    Route::get('/delete-customer-details/{id}','CustomerController@DeleteCustomerDetails')->name('admin.delete.customer');

    Route::get('/edit-customer-details/{id}','CustomerController@EditCustomerDetails')->name('admin.edit.customer');

    Route::post('/edit-customer-details/{id}','CustomerController@AdminEditCustomerDetails')->name('AdminEditCustomerDetails');

    //stock availabilty
    Route::get('/view-stock-availability','StockController@AvailableStocks')->name('admin.view.avaialable-stock');

    //purchased stock
    Route::get('/stock_purchase','StockController@CustomerStockPurchase')->name('customer.stock.purchase');

    Route::post('/stock_purchase','StockController@CheckPurchasedStock')->name('CheckPurchasedStock');

    Route::get('/view-stock_purchase','StockController@ViewStockPurchase')->name('view.stock.purchase');

    Route::get('/delete-stock_purchase/{id}','StockController@DeleteStockPurchase')->name('delete.stock.purchase');

    Route::get('/edit-stock_purchase/{id}','StockController@EditStockPurchase')->name('edit.stock.purchase');

    Route::post('/edit-stock_purchase/{id}','StockController@AdminStockPurchase')->name('AdminStockPurchase');

    Route::get('/sales-report','StockController@AdminSalesReport')->name('admin.sales.report');
});
Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
