@extends('admintemplate')
@section('content')
    <div class="container">
        <div class="row">
            <div class="col-md-6">
            <form action="{{route('AdminAddSuppliers')}}" method="post" enctype="multipart/form-data">
                {{ csrf_field() }}
                <div class="form-group">
                  <label for="">Supplier name</label>
                  <input type="text" class="form-control" name="supplier_name">
                </div>
                <div class="form-group">
                  <label for="">Supplier address</label>
                  <input type="text" class="form-control" name="supplier_address">
                </div>
                <div class="form-group">
                  <label for="">Supplier contactno</label>
                  <input type="text" class="form-control" name="contactno">
                </div>
                <button type="submit" class="btn btn-success">INSERT</button>
            </form>
            </div>
        </div>
    </div>
@endsection

