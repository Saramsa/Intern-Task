@extends('admintemplate')
@section('content')
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <table class="table table-dark">
                    <thead>
                        <tr>
                            <th>Supplier ID</th>
                            <th>Supplier Name</th>
                            <th>Supplier Address</th>
                            <th>Supplier ContactNo</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($sup_details as $item)
                        <tr>
                            <td scope="row">{{$item->id}}</td>
                            <td>{{$item->supplier_name}}</td>
                            <td>{{$item->supplier_address}}</td>
                            <td>{{$item->contactno}}</td>
                            <td><a class="btn btn-primary" href="{{route('admin.delete.suppliers',$item->id)}}" role="button">DELETE</a>
                                <a class="btn btn-success" href="{{route('admin.edit.suppliers',$item->id)}}" role="button">EDIT</a>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
@endsection

