@extends('admintemplate')
@section('content')
    <div class="container">
        <div class="row">
            <div class="col-md-6">
            <h1 class="text-center display-4">EDIT SUPPLIER DETAILS</h1>
            <form action="{{route('EditSuppliersDetails',$sup_details->id)}}" method="post" enctype="multipart/form-data">
                {{ csrf_field() }}
                <div class="form-group">
                  <label for="">Supplier name</label>
                    <input type="text" class="form-control" name="supplier_name" value="{{$sup_details->supplier_name}}">
                </div>
                <div class="form-group">
                  <label for="">Supplier address</label>
                  <input type="text" class="form-control" name="supplier_address" value="{{$sup_details->supplier_address}}">
                </div>
                <div class="form-group">
                  <label for="">Supplier contactno</label>
                  <input type="text" class="form-control" name="contactno" value="{{$sup_details->contactno}}">
                </div>
                <button type="submit" class="btn btn-success">EDIT</button>
            </form>
            </div>
        </div>
    </div>
@endsection

