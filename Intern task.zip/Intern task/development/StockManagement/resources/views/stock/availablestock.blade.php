@extends('admintemplate')
@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <h1 class="text-center display-4">Available Stock details</h1>
            <table class="table table-dark">
                <thead>
                    <tr>
                        <th>Product Image</th>
                        <th>Product Name</th>
                        <th>Product ID</th>
                        <th>Buying price</th>
                        <th>Selling price</th>
                        <th>Available Stock Quantity</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($stock_details as $item)
                    <tr>
                    <td scope="row"><img src="{{asset('images/product_images/'.$item->product_image)}}" width="100"></td>
                        <td>{{$item->product_name}}</td>
                        <td>{{$item->product_id}}</td>
                        <td>{{$item->buying_price}}</td>
                        <td>{{$item->selling_price}}</td>
                        <td>{{$item->stock_quantity}}</td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
@endsection