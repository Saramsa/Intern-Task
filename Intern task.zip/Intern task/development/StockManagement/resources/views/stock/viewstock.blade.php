@extends('admintemplate')
@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <h1 class="text-center display-4">Manage Stock details</h1>
            <table class="table table-dark">
                <thead>
                    <tr>
                        <th>Stock ID</th>
                        <th>Product ID</th>
                        <th>Product Image</th>
                        <th>Supplier ID</th>
                        <th>Buying price</th>
                        <th>selling price</th>
                        <th>Quantity</th>
                        <th>Total</th>
                        <th>Payment method</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                   @foreach ($stock_details as $item)
                   <tr>
                    <td scope="row">{{$item->id}}</td>
                        <td>{{$item->product_id}}</td>
                        <td><img src="{{asset('images/product_images/'.$item->product_image)}}" width="100"></td>
                        <td>{{$item->supplier_id}}</td>
                        <td>{{$item->buying_price}}</td>
                        <td>{{$item->selling_price}}</td>
                        <td>{{$item->quantity}}</td>
                        <td>{{$item->total}}</td>
                        <td>{{$item->pay_mode}}</td>
                        <td>{{$item->status}}</td>
                        <td><a class="btn btn-primary" href="{{route('admin.delete.stock',$item->id)}}" role="button">DELETE</a>
                            <a class="btn btn-danger" href="{{route('admin.edit.stock',$item->id)}}" role="button">EDIT</a>
                        </td>
                    </tr>
                   @endforeach
                </tbody>
            </table>
        </div>
    </div>
@endsection