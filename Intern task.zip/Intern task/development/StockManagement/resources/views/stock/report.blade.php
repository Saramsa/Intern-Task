@extends('admintemplate')
@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <h1 class="text-center display-4">General Sales Report</h1>
        </div>
        <div class="row">
            <div class="col-md-6">
                <h1 class="display-4">Total Customer<span class="badge badge-pill badge-primary">{{$total_customer}}</span></h1>
            </div>
            <div class="col-md-6">
                    <h1 class="display-4">Total Supplier<span class="badge badge-pill badge-danger">{{$total_supplier}}</span></h1>
            </div>
            <div class="col-md-6">
                    <h1 class="display-4">Total available stock<span class="badge badge-pill badge-success">{{$total_stock}}</span></h1>
            </div>
            <div class="col-md-6">
                    <h1 class="display-4">Total sales amount RS:<span class="badge badge-pill badge-warning">{{$total_sales}}</span></h1>
            </div>
            <div class="col-md-6">
                    <h1 class="display-4">Total amount of stock broughtin:<span class="badge badge-pill badge-warning">{{$total_broughtinstock}}</span></h1>
            </div>
        </div>
    </div>
@endsection