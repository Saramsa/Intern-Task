@extends('admintemplate')
@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <h1 class="text-center display-4">Purchased Stock Details</h1>
            <table class="table table-dark">
                <thead>
                    <tr>
                        <th>Product Image</th>
                        <th>Product name</th>
                        <th>Customer name</th>
                        <th>Price</th>
                        <th>Quantity</th>
                        <th>Payment</th>
                        <th>Status</th>
                        <th>Payment method</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($stock_details as $item)
                    <tr>
                        <td scope="row"><img src="{{asset('images/product_images/'.$item->product_image)}}" width="100"></td>
                        <td>{{$item->product_name}}</td>
                        <td>{{$item->customer_name}}</td>
                        <td>{{$item->price}}</td>
                        <td>{{$item->quantity}}</td>
                        <td>{{$item->payment}}</td>
                        <td>{{$item->status}}</td>
                        <td>{{$item->pay_mode}}</td>
                        <td><a class="btn btn-success" href="{{route('delete.stock.purchase',$item->id)}}" role="button">DELETE</a>
                            <a class="btn btn-primary" href="{{route('edit.stock.purchase',$item->id)}}" role="button">EDIT</a>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection