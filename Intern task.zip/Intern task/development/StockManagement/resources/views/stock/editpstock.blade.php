@extends('admintemplate')
@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <h1 class="text-center display-4">Edit Purchased Stock</h1>
        </div>
    </div>
<form action="" method="post" enctype="multipart/form-data">
            {{ csrf_field() }}
            <div class="row">
                    <div class="col-md-4">
                            <div class="form-group">
                                    <label for="">Product name</label>
                                    <select class="form-control" name="product_id">
                                    <option>Default</option>
                                    @foreach ($product_details as $item)
                                        <option value="{{$item->id}}">{{$item->product_name}}</option>   
                                    @endforeach
                                </select>
                            </div>
                        </div>
                        <div class="col-md-4">
                                <div class="form-group">
                                        <label for="">Customer name</label>
                                        <select class="form-control" name="customer_id">
                                        <option>Default</option>
                                        @foreach ($cust_details as $item)
                                            <option value="{{$item->id}}">{{$item->customer_name}}</option>   
                                        @endforeach
                                    </select>
                                </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                              <label for="">Available stock</label>
                            <input type="text" class="form-control" name="available_stock">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="">price</label>
                                <input type="text" class="form-control" name="price" value="{{$stock_details->price}}">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="">Qauntity</label>
                                <input type="text" class="form-control" name="quantity" value="{{$stock_details->quantity}}">
                            </div>
                        </div>
                        <div class="col-md-4">
                                <div class="form-group">
                                    <label for="">Total</label>
                                    <input type="text" class="form-control" name="total" value="{{$stock_details->total}}">
                                </div>
                            </div>
                            <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="">Due amount</label>
                                        <input type="text" class="form-control" name="due_amount" value="{{$stock_details->due_amount}}">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="">Payment</label>
                                        <input type="text" class="form-control" name="payment" value="{{$stock_details->payment}}">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                            <div class="form-group">
                                              <label for="">Status</label>
                                              <select class="form-control" name="status">
                                                <option>Paid</option>
                                                <option>Unpaid</option>
                                                <option>Due amount left</option>
                                              </select>
                                            </div>
                                        </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                      <label for="">Pay mode</label>
                                      <select class="form-control" name="pay_mode" id="">
                                        <option>Cash</option>
                                        <option>Cheque</option>
                                      </select>
                                    </div>
                                </div>       
            </div>
            <button type="submit" class="btn btn-success">SAVE</button>      
            <button type="reset" class="btn btn-danger">Cancel</button>
        </form>
</div>
@endsection