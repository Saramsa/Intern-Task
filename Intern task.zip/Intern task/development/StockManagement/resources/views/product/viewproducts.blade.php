@extends('admintemplate')
@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <h1 class="text-center display-4">Product details</h1>
                <table class="table table-dark">
                    <thead>
                        <tr>
                            <th>Product Id</th>
                            <th>Product name</th>
                            <th>Product description</th>
                            <th>Product category id</th>
                            <th>Product brand id</th>
                            <th>Product Image</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($product_details as $item)
                        <tr>
                            <td scope="row">{{$item->id}}</td>
                            <td>{{$item->product_name}}</td>
                            <td>{{$item->product_desc}}</td>
                            <td>{{$item->category_id}}</td>
                            <td>{{$item->brand_id}}</td>
                            <td><img src="{{asset('images/product_images/'.$item->product_image)}}" width="200"></td>
                            <td><a class="btn btn-primary" href="{{route('admin.delete.products',$item->id)}}" role="button">Delete</a>
                            <a class="btn btn-danger" href="{{route('admin.edit.products',$item->id)}}" role="button">Edit</a></td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
@endsection

