@extends('admintemplate')
@section('content')
    <div class="container">
        <div class="row">
            <div class="col-md-6">
            <form action="" method="post" enctype="multipart/form-data">
                {{ csrf_field() }}
                <h1 class="display-4">Edit Products</h1>
                <div class="form-group">
                        <label for="">Category</label>
                          <select name="category_id">
                                  @foreach ($cat_details as $item)
                                      <option value="{{$item->id}}">{{$item->categ_name}}</option>
                                  @endforeach
                          </select>
                      </div>
                      <div class="form-group">
                              <label for="">Brand</label>
                                <select name="brand_id">
                                  @foreach ($brand_details as $item)
                                      <option value="{{$item->id}}">{{$item->brand_name}}</option>
                                  @endforeach
                          </select>
                      </div>
                <div class="form-group">
                  <label for="">Product name</label>
                    <input type="text" class="form-control" name="product_name" value="{{$product_details->product_name}}">
                </div>
                <div class="form-group">
                  <label for="">Product description</label>
                  <textarea class="form-control" name="product_desc" rows="3">{{$product_details->product_desc}}</textarea>
                </div>
                <div class="form-group">
                  <label for="">Product price</label>
                  <input type="text" class="form-control" name="product_price" value="{{$product_details->product_price}}">
                </div>
                <div class="form-group">
                  <label for="">Product image</label>
                  <input type="file" class="form-control-file" name="product_image">
                    <img src="{{asset('images/product_images/'.$product_details->product_image)}}" width="200">
                </div>
                <button type="submit" class="btn btn-success">Edit</button>
            </form>
            </div>
        </div>
    </div>
@endsection

