@extends('admintemplate')
@section('content')
    <div class="container">
        <div class="row">
            <div class="col-md-6">
            <form action="{{route('EditBrands',$brand_details->id)}}" method="post" enctype="multipart/form-data">
                {{ csrf_field() }}
                <h1 class="display-4">Edit Brand</h1>
                <div class="form-group">
                  <label for="">Brand name</label>
                    <input type="text" class="form-control" name="brand_name" value="{{$brand_details->brand_name}}">
                </div>
                <div class="form-group">
                  <label for="">Brand description</label>
                  <textarea class="form-control" name="brand_desc" rows="3">{{$brand_details->brand_desc}}</textarea>
                </div>
                <button type="submit" class="btn btn-danger">SAVE</button>
                </form>
            </div>
        </div>
    </div>
@endsection

