@extends('admintemplate')
@section('content')
    <div class="container">
        <div class="row">
            <div class="col-md-12">
               <table class="table table-dark">
                   <thead>
                       <tr>
                           <th>Brand ID</th>
                           <th>Brand Name</th>
                           <th>Brand details</th>
                           <th>Action</th>
                       </tr>
                   </thead>
                   <tbody>
                       @foreach ($brand_details as $item)
                       <tr>
                            <td scope="row">{{$item->id}}</td>
                            <td>{{$item->brand_name}}</td>
                            <td>{{$item->brand_desc}}</td>
                            <td><a class="btn btn-primary" href="{{route('admin.delete.brands',$item->id)}}" role="button">DELETE</a>
                                <a class="btn btn-success" href="{{route('admin.edit.brands',$item->id)}}" role="button">EDIT</a>
                            </td>
                        </tr>
                       @endforeach
                   </tbody>
               </table>
            </div>
        </div>
    </div>
@endsection

