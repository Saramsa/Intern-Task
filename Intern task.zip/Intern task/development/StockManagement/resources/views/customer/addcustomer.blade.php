@extends('admintemplate')
@section('content')
    <div class="container">
        <div class="row">
            <div class="col-md-6">
            <form action="{{route('AdminAddCustomerDetails')}}" method="post" enctype="multipart/form-data">
                {{ csrf_field() }}
                <div class="form-group">
                  <label for="">Customer name</label>
                  <input type="text" class="form-control" name="customer_name">
                </div>
                <div class="form-group">
                  <label for="">Customer address</label>
                  <input type="text" class="form-control" name="customer_address">
                </div>
                <div class="form-group">
                  <label for="">Customer contactno</label>
                  <input type="text" class="form-control" name="contactno">
                </div>
                <button type="submit" class="btn btn-success">INSERT</button>
            </form>
            </div>
        </div>
    </div>
@endsection

