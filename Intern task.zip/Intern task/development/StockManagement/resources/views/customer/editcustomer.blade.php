@extends('admintemplate')
@section('content')
    <div class="container">
        <div class="row">
            <div class="col-md-6">
            <h1 class="text-center display-4">Edit Customer details</h1>
            <form action="{{route('AdminEditCustomerDetails',$cust_details->id)}}" method="post" enctype="multipart/form-data">
                {{ csrf_field() }}
                <div class="form-group">
                  <label for="">Customer name</label>
                <input type="text" class="form-control" name="customer_name" value="{{$cust_details->customer_name}}">
                </div>
                <div class="form-group">
                  <label for="">Customer address</label>
                  <input type="text" class="form-control" name="customer_address" value="{{$cust_details->customer_address}}">
                </div>
                <div class="form-group">
                  <label for="">Customer contactno</label>
                  <input type="text" class="form-control" name="contactno" value="{{$cust_details->contactno}}">
                </div>
                <button type="submit" class="btn btn-success">INSERT</button>
            </form>
            </div>
        </div>
    </div>
@endsection

