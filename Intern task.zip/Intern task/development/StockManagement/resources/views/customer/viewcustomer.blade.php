@extends('admintemplate')
@section('content')
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <table class="table table-dark">
                    <thead>
                        <tr>
                            <th>Customer ID</th>
                            <th>Customer Name</th>
                            <th>Customer Address</th>
                            <th>Customer Contact No</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                       @foreach ($cust_details as $item)
                       <tr>
                            <td scope="row">{{$item->id}}</td>
                            <td>{{$item->customer_name}}</td>
                            <td>{{$item->customer_address}}</td>
                            <td>{{$item->contactno}}</td>
                       <td><a name="" id="" class="btn btn-danger" href="{{route('admin.delete.customer',$item->id)}}" role="button">DELETE</a>
                            <a name="" id="" class="btn btn-primary" href="{{route('admin.edit.customer',$item->id)}}" role="button">EDIT</a></td>
                        </tr>
                       @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
@endsection

