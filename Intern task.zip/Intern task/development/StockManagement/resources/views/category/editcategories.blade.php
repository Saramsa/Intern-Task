@extends('admintemplate')
@section('content')
    <div class="container">
        <div class="row">
            <div class="col-md-6">
            <form action="{{route('EditedCategories',$cat_details->id)}}" method="post" enctype="multipart/form-data">
                {{ csrf_field() }}
                <h1 class="display-4">Edit Categories</h1>
                <div class="form-group">
                  <label for="">Category name</label>
                <input type="text" class="form-control" name="categ_name" value="{{$cat_details->categ_name}}">
                </div>
                <div class="form-group">
                  <label for="">Category description</label>
                <textarea class="form-control" name="categ_desc" rows="3">{{$cat_details->categ_desc}}</textarea>
                </div>
                <button type="submit" class="btn btn-danger">SAVE</button>
                </form>
            </div>
        </div>
    </div>
@endsection

