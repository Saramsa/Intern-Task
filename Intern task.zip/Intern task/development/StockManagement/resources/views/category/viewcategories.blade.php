@extends('admintemplate')
@section('content')
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <table class="table table-dark">
                    <thead>
                        <tr>
                            <th>Category id</th>
                            <th>Category name</th>
                            <th>Category description</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($cat_details as $item)
                        <tr>
                        <td scope="row">{{$item->id}}</td>
                            <td>{{$item->categ_name}}</td>
                            <td>{{$item->categ_desc}}</td>
                        <td><a class="btn btn-danger" href="{{route('admin.delete.categories',$item->id)}}" role="button">DELETE</a>
                            <a class="btn btn-primary" href="{{route('admin.edit.categories',$item->id)}}" role="button">EDIT</a></td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
@endsection

