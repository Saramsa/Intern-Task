@extends('admintemplate')
@section('content')
    <div class="jumbotron">
    <h1 class="display-3 text-center">Welcome {{$admin_details->username}}</h1>
        <hr class="my-2">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <ul class="list-group">
                        <li class="list-group-item"><a class="btn btn-primary" href="{{route('admin.add.stock')}}" role="button">Add Stock details</a></li>
                        <li class="list-group-item"><a class="btn btn-danger" href="{{route('admin.view.stock')}}" role="button">Manage Stock details</a></li>
                        <li class="list-group-item"><a class="btn btn-success" href="{{route('customer.stock.purchase')}}" role="button">Purchase Stock</a></li>
                        <li class="list-group-item"><a class="btn btn-primary" href="{{route('view.stock.purchase')}}" role="button">Manage Purchase Stock details</a></li>
                        <li class="list-group-item"><a class="btn btn-success" href="{{route('admin.view.avaialable-stock')}}" role="button">View Stock availability</a></li>
                        <li class="list-group-item"><a class="btn btn-danger" href="{{route('admin.sales.report')}}" role="button">General Sales Report</a></li>
                     </ul>
                </div>
            </div>
        </div>
    </div>
@endsection

