<?php

namespace App\Http\Middleware;

use Closure;

use Session;

class adminlogincheck
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if(empty(Session::has('adminsession')))
        {
            return redirect()->route('admin.login')->with('message','PLease login to get access');
        }
        return $next($request);
    }
}
