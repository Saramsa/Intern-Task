<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Customer;

class CustomerController extends Controller
{
    public function __construct()
    {
        return $this->middleware('auth:admin');
    }
    public function AddCustomerDetails()
    {
        return view('customer.addcustomer');
    }
    public function AdminAddCustomerDetails(Request $request)
    {
        $this->validate($request,[
            'customer_name'=>'required|max:255',
            'customer_address'=>'required|max:255',
            'contactno'=>'required|numeric|digits:10',
        ]);

        $data=$request->all();

        $cust_details=new Customer;
        $cust_details->customer_name=$data['customer_name'];
        $cust_details->customer_address=$data['customer_address'];
        $cust_details->contactno=$data['contactno'];
        $cust_details->save();
        return redirect()->route('admin.view.customer')->with('message','Customer details inserted successfully');
    }
    public function ViewCustomerDetails()
    {
        $cust_details=Customer::get();
        return view('customer.viewcustomer',compact('cust_details'));
    }
    public function DeleteCustomerDetails(Customer $id)
    {
        $id->delete();
        return redirect()->route('admin.view.customer')->with('message','Customer details inserted successfully');
    }
    public function EditCustomerDetails($id)
    {
        $cust_details=Customer::findorfail($id);
        return view('customer.editcustomer',compact('cust_details'));
    }
    public function AdminEditCustomerDetails(Customer $id,Request $request)
    {
        $this->validate($request,[
            'customer_name'=>'required|max:255',
            'customer_address'=>'required|max:255',
            'contactno'=>'required|numeric|digits:10',
        ]);

        $data=$request->all();

        $id->customer_name=$data['customer_name'];
        $id->customer_address=$data['customer_address'];
        $id->contactno=$data['contactno'];
        $id->save();
        return redirect()->route('admin.view.customer')->with('message','Customer details edited successfully');
    }
}

