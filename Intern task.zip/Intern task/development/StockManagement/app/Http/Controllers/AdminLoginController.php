<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Auth;

use Session;

class AdminLoginController extends Controller
{
    public function __construct()
    {
        $this->middleware('guest:admin')->except('logout','AdminLogout');
    }
    public function AdminviewLogin()
    {
        return view('admin.adminlogin');
    }
    public function AdminLogin(Request $request)
    {
        $this->validate($request,[
            'username'=>'required|max:255',
            'password'=>'required|max:255',
        ]);

        if(Auth::guard('admin')->attempt(['username'=>$request->username,'password'=>$request->password]))
        {
            Session::put('adminsession',$request->username);
            return redirect()->route('admin.home');
        }
        return redirect()->route('admin.login')->with('message','Username or password in incorrect');
    }
    public function AdminLogout()
    {
        Auth::guard('admin')->logout();
        Session::forget('adminsession');
        return redirect()->route('admin.login')->with('message','Logged out successfully');
    }
}
