<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Product;

use App\stock_available;

use App\Stock;

use App\Supplier;

use App\Customer;

use App\Stock_Purchased;

class StockController extends Controller
{
    public function __construct()
    {
        return $this->middleware('auth:admin');
    }
    public function AddStockDetails()
    {
        $product_details=Product::get();
        $supplier_details=Supplier::get();
        return view('stock.addstock',compact('product_details','supplier_details'));
    }
    public function AdminAddStockDetails(Request $request)
    {
        $this->validate($request,[
            'product_id'=>'required',
            'supplier_id'=>'required',
            'buying_price'=>'required|numeric',
            'selling_price'=>'required|numeric',
            'quantity'=>'required|numeric',
            'total'=>'required|numeric',
            'due_amount'=>'sometimes',
            'payment'=>'required|numeric',
            'status'=>'required',
            'pay_mode'=>'required',
        ]);

        $data=$request->all();

        $stock_details=new Stock;
        $stock_details->product_id=$data['product_id'];
        $stock_details->supplier_id=$data['supplier_id'];
        $stock_details->buying_price=$data['buying_price']; 
        $stock_details->selling_price=$data['selling_price']; 
        $stock_details->quantity=$data['quantity']; 
        $stock_details->total=$data['total']; 
        $stock_details->due_amount=$data['due_amount']; 
        $stock_details->payment=$data['payment']; 
        $stock_details->status=$data['status']; 
        $stock_details->pay_mode=$data['pay_mode']; 
        $stock_details->save();

        $product_id=$data['product_id'];

        $product_price=$data['selling_price'];

        Product::where('id',$product_id)->update(['product_price'=>$product_price]);

        $product_count=stock_available::where('product_id',$product_id)->count();

        // $avaialble_productid=stock_available::where('product_id',$product_id)->get();

        // $totalstock=stock_available::where('product_id',$product_id)->sum('stock_quantity');

        $totalstock=Stock::where('product_id',$product_id)->sum('quantity');

        if($product_count == 0)
        {
            $st_available=new stock_available;
            $st_available->product_id=$data['product_id'];
            $st_available->buying_price=$data['buying_price'];;
            $st_available->selling_price=$data['selling_price'];
            $st_available->stock_quantity=$data['quantity'];
            $st_available->save();   
        }else{
            stock_available::where('product_id',$product_id)->update(['stock_quantity'=>$totalstock]);
            // stock_available::where('product_id',$product_id)->increment('stock_quantity',$totalstock);
        }
        
        return redirect()->back()->with('message','Stock details inserted successfully');
    }
    public function ViewStockDetails()
    {
        $stock_details=Stock::get();
        foreach($stock_details as $details=>$product)
        {
            $product_details=Product::where('id',$product->product_id)->first();
            $stock_details[$details]->product_image=$product_details->product_image;
        }
        return view('stock.viewstock',compact('stock_details'));
    }
    public function DeleteStockDetails(Stock $id)
    {
        $id->delete();
        return redirect()->route('admin.view.stock')->with('message','Stock details deleted successfully');
    }
    public function AvailableStocks()
    {
        $stock_details=stock_available::get();
        foreach($stock_details as $details=>$product)
        {
            $product_details=Product::where('id',$product->product_id)->first();
            $stock_details[$details]->product_image=$product_details->product_image;
            $stock_details[$details]->product_name=$product_details->product_name;
        }
        return view('stock.availablestock',compact('stock_details'));
    }
    public function EditStockDetails($id)
    {
        $product_details=Product::get();
        $supplier_details=Supplier::get();
        $stock_details=Stock::where('id',$id)->first();
        $product_name=Product::where('id',$stock_details->product_id)->first();
        $st_available=stock_available::where('product_id',$stock_details->product_id)->first();
        return view('stock.editstock',compact('stock_details','product_details','supplier_details','st_available','product_name'));
    }
    public function AdminEditStockDetails(Stock $id,Request $request)
    {
        $this->validate($request,[
            'product_id'=>'required',
            'supplier_id'=>'required',
            'buying_price'=>'required|numeric',
            'selling_price'=>'required|numeric',
            'quantity'=>'required|numeric',
            'total'=>'required|numeric',
            'due_amount'=>'sometimes',
            'payment'=>'required|numeric',
            'status'=>'required',
            'pay_mode'=>'required',
        ]);

        $data=$request->all();
        
        $id->product_id=$data['product_id'];
        $id->supplier_id=$data['supplier_id'];
        $id->buying_price=$data['buying_price']; 
        $id->selling_price=$data['selling_price']; 
        $id->quantity=$data['quantity']; 
        $id->total=$data['total']; 
        $id->due_amount=$data['due_amount']; 
        $id->payment=$data['payment']; 
        $id->status=$data['status']; 
        $id->pay_mode=$data['pay_mode']; 
        $id->save();

        $product_id=$data['product_id'];

        $product_price=$data['selling_price'];

        Product::where('id',$product_id)->update(['product_price'=>$product_price]);

        $totalstock=Stock::where('product_id',$product_id)->sum('quantity');

        stock_available::where('product_id',$product_id)->update(['stock_quantity'=>$totalstock]);
        
        return redirect()->route('admin.view.stock')->with('message','Stock details edited successfully');
    }
    public function CustomerStockPurchase()
    {
        $product_details=Product::get();
        $cust_details=Customer::get();
        return view('stock.purchasestock',compact('product_details','cust_details'));
    }
    public function CheckPurchasedStock(Request $request)
    {
        $this->validate($request,[
            'product_id'=>'required',
            'customer_id'=>'required',
            'price'=>'required|numeric',
            'quantity'=>'required|numeric',
            'total'=>'required|numeric',
            'due_amount'=>'sometimes',
            'payment'=>'required|numeric',
            'status'=>'required',
            'pay_mode'=>'required',
        ]);

        $data=$request->all();

        $product_id=$data['product_id'];

        $product_details=Product::where('id',$product_id)->first();

        $product_name=$product_details->product_name;

        $product_quantity=$data['quantity'];

        $stock_details=stock_available::where('product_id',$product_id)->first();

        $stock_quantity=$stock_details->stock_quantity;

        if($product_quantity>$stock_quantity)
        {
            return redirect()->back()->with('message','Only '.$stock_quantity.' items of '.$product_name.' available');
        }else{
            $purchase_details=new Stock_Purchased;
            $purchase_details->product_id=$product_id;
            $purchase_details->customer_id=$data['customer_id'];
            $purchase_details->price=$data['price'];
            $purchase_details->quantity=$product_quantity;
            $purchase_details->total=$data['total'];
            $purchase_details->due_amount=$data['due_amount'];
            $purchase_details->payment=$data['payment'];
            $purchase_details->status=$data['status'];
            $purchase_details->pay_mode=$data['pay_mode'];
            $purchase_details->save();

            stock_available::where('product_id',$product_id)->decrement('stock_quantity',$product_quantity);
            return redirect()->back()->with('message','Stock purchase details recorded successfully');
        }
    }
    public function ViewStockPurchase()
    {
        $stock_details=Stock_Purchased::get();
        foreach($stock_details as $details=>$product)
        {
            $product_details=Product::where('id',$product->product_id)->first();
            $customer_details=Customer::where('id',$product->customer_id)->first();
            $stock_details[$details]->customer_name=$customer_details->customer_name;
            $stock_details[$details]->product_image=$product_details->product_image;
            $stock_details[$details]->product_name=$product_details->product_name;
        }
        return view('stock.viewstockpurchase',compact('stock_details'));
    }
    public function DeleteStockPurchase(Stock_Purchased $id)
    {   
        $id->delete();
        return redirect()->back()->with('message','Stock purchase details deleted successfully');
    }
    public function EditStockPurchase($id)
    {
        $product_details=Product::get();
        $cust_details=Customer::get();
        $stock_details=Stock_Purchased::where('id',$id)->first();
        return view('stock.editpstock',compact('product_details','cust_details','stock_details'));
    }
    public function AdminStockPurchase(Stock_Purchased $id,Request $request)
    {
        $this->validate($request,[
            'product_id'=>'required',
            'customer_id'=>'required',
            'price'=>'required|numeric',
            'quantity'=>'required|numeric',
            'total'=>'required|numeric',
            'due_amount'=>'sometimes',
            'payment'=>'required|numeric',
            'status'=>'required',
            'pay_mode'=>'required',
        ]);

        $data=$request->all();

        $product_id=$data['product_id'];

        $product_details=Product::where('id',$product_id)->first();

        $product_name=$product_details->product_name;

        $product_quantity=$data['quantity'];

        $stock_details=stock_available::where('product_id',$product_id)->first();

        $stock_quantity=$stock_details->stock_quantity;
        
        if($product_quantity>$stock_quantity)
        {
            return redirect()->back()->with('message','Only '.$stock_quantity.' items of '.$product_name.' available');
        }else{
            $id->product_id=$product_id;
            $id->customer_id=$data['customer_id'];
            $id->price=$data['price'];
            $id->quantity=$product_quantity;
            $id->total=$data['total'];
            $id->due_amount=$data['due_amount'];
            $id->payment=$data['payment'];
            $id->status=$data['status'];
            $id->pay_mode=$data['pay_mode'];
            $id->save();

            stock_available::where('product_id',$product_id)->decrement('stock_quantity',$product_quantity);
            return redirect()->back()->with('message','Stock purchase details recorded successfully');
        }
    }
    public function AdminSalesReport()
    {
        $total_customer=Customer::get()->count();
        $total_supplier=Supplier::get()->count();
        $total_stock=stock_available::get()->sum('stock_quantity');
        $total_sales=Stock_Purchased::get()->sum('payment');
        $total_broughtinstock=Stock::get()->sum('quantity');
        return view('stock.report',compact('total_customer','total_supplier','total_stock','total_sales','total_broughtinstock'));
    }
}
