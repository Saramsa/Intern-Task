<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Admin;

use App\Brand;

class AdminDashboardController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:admin');
    }
    public function AdminDashboard()
    {
        $admin_details=Admin::first();
        return view('admin.admindashboard',compact('admin_details'));
    }
    public function AdminAddBrands(Request $request)
    {
        return view('brand.addbrands');
    }
    public function AddBrands(Request $request) 
    {
        $this->validate($request,[
            'brand_name'=>'required|max:255',
            'brand_desc'=>'required|max:255',
        ]);

        $brands=new Brand;
        $brands->brand_name=$request->brand_name;
        $brands->brand_desc=$request->brand_desc;
        $brands->save();
        return redirect()->back()->with('message','Brand details inserted successfully');
    }
    public function AdminViewBrands()
    {
        $brand_details=Brand::get();
        return view('brand.viewbrands',compact('brand_details'));
    }
    public function AdminDeleteBrands(Brand $id)
    {
        $id->delete();
        return redirect()->route('admin.view.brands')->with('message','Brand details deleted successfully');
    }
    public function AdminEditBrands($id)
    {
        $brand_count=Brand::where('id',$id)->count();
        $brand_details=Brand::find($id);
        if($brand_count==0)
        {
            return redirect()->route('admin.view.brands')->with('message','Brand details does not exists');            
        }
        return view('brand.editbrands',compact('brand_details'));
    }
    public function EditBrands(Request $request,Brand $id)
    {
        $this->validate($request,[
            'brand_name'=>'required|max:255',
            'brand_desc'=>'required|max:255',
        ]);
        
        $id->brand_name=$request->brand_name;
        $id->brand_desc=$request->brand_desc;
        $id->save();
        return redirect()->route('admin.view.brands')->with('message','Brand details updated successfully');            
    }
}
