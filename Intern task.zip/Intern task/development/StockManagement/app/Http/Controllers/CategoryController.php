<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Category;

use DateTime;

class CategoryController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:admin');
    }
    public function AdminAddCategories()
    {
        return view('category.addcategory');
    }
    public function AddedCategories(Request $request)
    {
        $this->validate($request,[
            'categ_name'=>'required|max:255',
            'categ_desc'=>'required|max:255',
        ]);

        $data=$request->all();
        
        // Category::insert(['categ_name'=>$data['categ_name'],'categ_desc'=>$data['categ_desc']]);

        $categories=new Category;
        $categories->categ_name=$data['categ_name'];
        $categories->categ_desc=$data['categ_desc'];
        $categories->save();
        
        return redirect()->back()->with('message','Category inserted successfully');
    }
    public function AdminViewCategories()
    {
        $cat_details=Category::get();
        return view('category.viewcategories',compact('cat_details'));
    }
    public function AdminDeleteCategories(Category $id)
    {
        $id->delete();
        return redirect()->route('admin.view.categories')->with('message','Category deleted successfully');
    }
    public function AdminEditCategories(Request $request,$id)
    {
        $cat_details=Category::where('id',$id)->first();
        return view('category.editcategories',compact('cat_details'));
    }
    public function EditedCategories(Request $request,Category $id)
    {
        $this->validate($request,[
            'categ_name'=>'required|max:255',
            'categ_desc'=>'required|max:255',
        ]);

        $id->categ_name=$request->categ_name;
        $id->categ_desc=$request->categ_desc;
        $id->save();
        return redirect()->route('admin.view.categories')->with('message','Category edited successfully');
    }
}
