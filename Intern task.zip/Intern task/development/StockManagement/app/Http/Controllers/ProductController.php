<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Category;

use App\Brand;

use App\Product;

use App\Supplier;

class ProductController extends Controller
{
    public function __construct()
    {
        return $this->middleware('auth:admin');
    }
    public function AdminAddProducts()
    {
        $cat_details=Category::get();
        $brand_details=Brand::get();
        return view('product.addproducts',compact('cat_details','brand_details'));
    }
    public function AddProducts(Request $request)
    {
        $this->validate($request,[
            'category_id'=>'required',
            'brand_id'=>'required',
            'product_name'=>'required|max:255',
            'product_desc'=>'required',
            'product_price'=>'required|numeric',
            'product_image'=>'required|image|mimes:jpeg,jpg,png',
        ]);

        $data=$request->all();

        $image=$data['product_image'];

        $extension=$image->getClientOriginalExtension();

        $uniq_name=sha1(time());

        $destination=public_path('/images/product_images');

        $new_imagename=$uniq_name.".".$extension;
        
        $product_details=new Product;
        $product_details->product_name=$data['product_name'];
        $product_details->product_desc=$data['product_desc'];
        $product_details->product_desc=$data['product_desc'];
        $product_details->product_price=$data['product_price'];
        $product_details->product_image=$new_imagename;
        $product_details->category_id=$data['category_id'];
        $product_details->brand_id=$data['brand_id'];
        $product_details->save();
        $image->move($destination,$new_imagename);
        return redirect()->back()->with('message','Product inserted successfully');
    }
    public function ViewProducts()
    {
        $product_details=Product::get();
        return view('product.viewproducts',compact('product_details'));
    }
    public function DeleteProducts(Product $id)
    {
        $id->delete();
        return redirect()->route('admin.view.products')->with('message','Product inserted successfully');
    }
    public function EditProducts($id)
    {
        $cat_details=Category::get();
        $brand_details=Brand::get();
        $product_details=Product::find($id);
        return view('product.editproduct',compact('product_details','cat_details','brand_details'));
    }
    public function AdminEditProducts(Request $request,Product $id)
    {
        $this->validate($request,[
            'category_id'=>'required',
            'brand_id'=>'required',
            'product_name'=>'required|max:255',
            'product_desc'=>'required|max:255',
            'product_price'=>'required|numeric',
            'product_image'=>'sometimes|image|mimes:jpeg,jpg,png',
        ]);

        $data=$request->all();

        if($request->has('product_image'))
        {

        $image=$data['product_image'];

        $extension=$image->getClientOriginalExtension();

        $uniq_name=sha1(time());

        $destination=public_path('/images/product_images');

        $new_imagename=$uniq_name.".".$extension;
        
        $id->product_name=$data['product_name'];
        $id->product_desc=$data['product_desc'];
        $id->product_desc=$data['product_desc'];
        $id->product_price=$data['product_price'];
        $id->product_image=$new_imagename;
        $id->category_id=$data['category_id'];
        $id->brand_id=$data['brand_id'];
        $id->save();
        $image->move($destination,$new_imagename);
        return redirect()->back()->with('message','Product edited successfully');
        }else{
            $id->product_name=$data['product_name'];
            $id->product_desc=$data['product_desc'];
            $id->product_desc=$data['product_desc'];
            $id->product_price=$data['product_price'];
            $id->category_id=$data['category_id'];
            $id->brand_id=$data['brand_id'];
            $id->save();
            return redirect()->back()->with('message','Product edited successfully');
        }
    }
    public function AddSuppliers()
    {
        return view('supplier.addsupplier');
    }
    public function AdminAddSuppliers(Request $request)
    {
        $this->validate($request,[
            'supplier_name'=>'required|max:255',
            'supplier_address'=>'required|max:255',
            'contactno'=>'required|numeric|digits:10',
        ]);

        $data=$request->all();

        Supplier::insert(['supplier_name'=>$data['supplier_name'],'supplier_address'=>$data['supplier_address'],
        'contactno'=>$data['contactno']]);
        return redirect()->route('admin.view.suppliers')->with('message','Supplier details inserted successfully');
    }
    public function AdminViewSuppliers()
    {
        $sup_details=Supplier::get();
        return view('supplier.viewsuppliers',compact('sup_details'));
    }
    public function AdminDeleteSuppliers(Supplier $id)
    {
        $id->delete();
        return redirect()->route('admin.view.suppliers')->with('message','Supplier details deleted successfully');
    }
    public function AdminEditSuppliers($id)
    {
        $sup_details=Supplier::findorfail($id);
        return view('supplier.editsupplier',compact('sup_details'));
    }
    public function EditSuppliersDetails($id,Request $request)
    {
        $this->validate($request,[
            'supplier_name'=>'required|max:255',
            'supplier_address'=>'required|max:255',
            'contactno'=>'required|numeric|digits:10',
        ]);
        
        $data=$request->all();
        
        Supplier::where('id',$id)->update(['supplier_name'=>$data['supplier_name'],'supplier_address'=>$data['supplier_address'],
        'contactno'=>$data['contactno']]);
        return redirect()->route('admin.view.suppliers')->with('message','Supplier details updated successfully');
    }
}
