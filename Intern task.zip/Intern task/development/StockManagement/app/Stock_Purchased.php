<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Stock_Purchased extends Model
{
    //
}
