The route for admin login is
localhost:8000/admin/login
Username:Admin
Password:123456